export const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

export const formatDate = (date: Date): string => {
  return new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  }).format(date);
};

export const truncateText = (text: string, maxLength: number): string => {
  if (text.length <= maxLength) return text;
  return text.substr(0, maxLength) + '...';
};

export const extractKeyPoints = (content: string): string[] => {
  const sentences = content.split(/[.!?]+/).filter(s => s.trim().length > 10);
  const keyWords = ['important', 'key', 'main', 'summary', 'conclusion', 'result', 'therefore', 'because'];
  
  return sentences
    .filter(sentence => keyWords.some(keyword => sentence.toLowerCase().includes(keyword)))
    .slice(0, 5);
};

export const detectLanguage = (text: string): string => {
  // Simple language detection based on character patterns
  const hindiPattern = /[\u0900-\u097F]/;
  const teluguPattern = /[\u0C00-\u0C7F]/;
  
  if (hindiPattern.test(text)) return 'hi-IN';
  if (teluguPattern.test(text)) return 'te-IN';
  return 'en-US';
};

export const cleanText = (text: string): string => {
  // Remove extra whitespace and clean up formatting
  return text
    .replace(/\s+/g, ' ')
    .replace(/\n\s*\n/g, '\n\n')
    .trim();
};

export const generateAccessibleId = (prefix: string): string => {
  return `${prefix}-${Math.random().toString(36).substr(2, 9)}`;
};