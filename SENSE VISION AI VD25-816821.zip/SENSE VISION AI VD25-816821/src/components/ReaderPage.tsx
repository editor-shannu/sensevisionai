import React, { useState, useCallback } from 'react';
import { Play, Pause, SkipBack, SkipForward, Volume2, Globe } from 'lucide-react';
import { StudyFile } from '../types';
import { useTextToSpeech } from '../hooks/useTextToSpeech';
import { useVoiceCommands } from '../hooks/useVoiceCommands';

interface ReaderPageProps {
  files: StudyFile[];
  selectedFile: StudyFile | null;
  onFileSelect: (file: StudyFile) => void;
}

const ReaderPage: React.FC<ReaderPageProps> = ({ files, selectedFile, onFileSelect }) => {
  const [currentSentenceIndex, setCurrentSentenceIndex] = useState(0);
  const [speed, setSpeed] = useState(1);
  const [volume, setVolume] = useState(80);
  const [selectedLanguage, setSelectedLanguage] = useState('en-US');

  const {
    speak,
    pause,
    resume,
    stop,
    isPlaying,
    settings,
    setSettings
  } = useTextToSpeech();

  const handleVoiceCommand = useCallback((action: string) => {
    switch (action) {
      case 'pause':
        pause();
        break;
      case 'resume':
        resume();
        break;
      case 'slowDown':
        setSpeed(prev => Math.max(0.5, prev - 0.1));
        break;
      case 'speedUp':
        setSpeed(prev => Math.min(2.0, prev + 0.1));
        break;
      case 'repeatLine':
        if (selectedFile?.content) {
          const sentences = selectedFile.content.split(/[.!?]+/);
          if (sentences[currentSentenceIndex]) {
            speak(sentences[currentSentenceIndex]);
          }
        }
        break;
    }
  }, [pause, resume, speak, selectedFile, currentSentenceIndex]);

  const { isListening, startListening, stopListening } = useVoiceCommands(handleVoiceCommand);

  const handlePlay = useCallback(() => {
    if (selectedFile?.content) {
      speak(selectedFile.content);
    }
  }, [selectedFile, speak]);

  const handlePrevious = useCallback(() => {
    if (selectedFile?.content) {
      const sentences = selectedFile.content.split(/[.!?]+/);
      const newIndex = Math.max(0, currentSentenceIndex - 1);
      setCurrentSentenceIndex(newIndex);
      if (sentences[newIndex]) {
        speak(sentences[newIndex]);
      }
    }
  }, [selectedFile, currentSentenceIndex, speak]);

  const handleNext = useCallback(() => {
    if (selectedFile?.content) {
      const sentences = selectedFile.content.split(/[.!?]+/);
      const newIndex = Math.min(sentences.length - 1, currentSentenceIndex + 1);
      setCurrentSentenceIndex(newIndex);
      if (sentences[newIndex]) {
        speak(sentences[newIndex]);
      }
    }
  }, [selectedFile, currentSentenceIndex, speak]);

  const textFiles = files.filter(f => f.contentType === 'text' || !f.contentType);

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-4 sm:py-8">
      {/* Header */}
      <div className="text-center mb-6 sm:mb-8">
        <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-2">Text Reader</h2>
        <p className="text-sm sm:text-base text-gray-600">Select and listen to your study materials</p>
      </div>

      {/* File Selection */}
      <div className="mb-6 sm:mb-8">
        <h3 className="text-lg sm:text-xl font-bold text-gray-800 mb-4">Your Text Materials</h3>
        <div className="space-y-3">
          {textFiles.map((file) => (
            <button
              key={file.id}
              onClick={() => onFileSelect(file)}
              className={`w-full p-3 sm:p-4 rounded-2xl text-left transition-all duration-300 mobile-touch-target ${
                selectedFile?.id === file.id
                  ? 'bg-gradient-to-br from-purple-200 to-purple-300 shadow-clay-inset'
                  : 'bg-white shadow-clay-soft hover:shadow-clay-hover'
              }`}
            >
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 rounded-full bg-green-500"></div>
                <div className="flex-1">
                  <h4 className="text-sm sm:text-base font-medium text-gray-800 truncate">{file.name}</h4>
                  {file.summary && (
                    <p className="text-xs sm:text-sm text-gray-600 mt-1 line-clamp-2">{file.summary}</p>
                  )}
                </div>
              </div>
            </button>
          ))}
          
          {textFiles.length === 0 && (
            <div className="text-center py-8 sm:py-12">
              <p className="text-sm sm:text-base text-gray-500">No text materials found. Upload some documents from the Home page.</p>
            </div>
          )}
        </div>
      </div>

      {/* Reader Interface */}
      {selectedFile && (
        <div className="space-y-6">
          {/* Language Selection */}
          <div className="bg-white p-4 sm:p-6 rounded-3xl shadow-clay-soft">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <Globe className="w-5 h-5 text-purple-600" />
                <h3 className="text-base sm:text-lg font-bold text-gray-800">Reading Language</h3>
              </div>
              <select
                value={selectedLanguage}
                onChange={(e) => {
                  setSelectedLanguage(e.target.value);
                  setSettings(prev => ({ ...prev, language: e.target.value }));
                }}
                className="px-3 py-2 rounded-2xl border-2 border-gray-200 bg-white shadow-clay-soft focus:shadow-clay-inset focus:border-purple-300 outline-none transition-all duration-200 text-sm mobile-text text-gray-800 font-medium"
              >
                <option value="en-US">English</option>
                <option value="hi-IN">Hindi</option>
                <option value="te-IN">Telugu</option>
              </select>
            </div>
          </div>

          {/* Now Reading */}
          <div className="bg-white p-4 sm:p-6 rounded-3xl shadow-clay-soft">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base sm:text-lg font-bold text-gray-800">Now Reading</h3>
              <div className="flex items-center space-x-2 text-xs sm:text-sm text-gray-600">
                <span>{selectedLanguage === 'en-US' ? 'english' : selectedLanguage === 'hi-IN' ? 'hindi' : 'telugu'}</span>
                <span>•</span>
                <span>academic</span>
              </div>
            </div>
            
            <div className="bg-gray-50 p-3 sm:p-4 rounded-2xl mb-4 sm:mb-6">
              <h4 className="text-sm sm:text-base font-medium text-gray-800 mb-2 truncate">{selectedFile.name}</h4>
              <div className="text-sm sm:text-base text-gray-700 leading-relaxed max-h-48 sm:max-h-64 overflow-y-auto">
                {selectedFile.content}
              </div>
            </div>

            {/* Playback Controls */}
            <div className="flex items-center justify-center space-x-3 sm:space-x-4 mb-4 sm:mb-6">
              <button
                onClick={handlePrevious}
                className="p-2 sm:p-3 rounded-2xl bg-gradient-to-br from-purple-200 to-purple-300 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300 mobile-touch-target"
              >
                <SkipBack className="w-5 h-5 sm:w-6 sm:h-6 text-purple-700" />
              </button>
              
              <button
                onClick={isPlaying ? pause : handlePlay}
                className="p-3 sm:p-4 rounded-2xl bg-gradient-to-br from-purple-200 to-purple-300 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300 mobile-touch-target"
              >
                {isPlaying ? (
                  <Pause className="w-6 h-6 sm:w-8 sm:h-8 text-purple-700" />
                ) : (
                  <Play className="w-6 h-6 sm:w-8 sm:h-8 text-purple-700" />
                )}
              </button>
              
              <button
                onClick={handleNext}
                className="p-2 sm:p-3 rounded-2xl bg-gradient-to-br from-purple-200 to-purple-300 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300 mobile-touch-target"
              >
                <SkipForward className="w-5 h-5 sm:w-6 sm:h-6 text-purple-700" />
              </button>
            </div>

            {/* Speed and Volume Controls */}
            <div className="space-y-4">
              <div className="flex items-center space-x-4">
                <Volume2 className="w-4 h-4 sm:w-5 sm:h-5 text-gray-600" />
                <span className="text-xs sm:text-sm font-medium text-gray-700 w-12 sm:w-16">Speed: {speed.toFixed(1)}x</span>
                <input
                  type="range"
                  min="0.5"
                  max="2.0"
                  step="0.1"
                  value={speed}
                  onChange={(e) => {
                    const newSpeed = parseFloat(e.target.value);
                    setSpeed(newSpeed);
                    setSettings(prev => ({ ...prev, speed: newSpeed }));
                  }}
                  className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                />
              </div>
              
              <div className="flex items-center space-x-4">
                <Volume2 className="w-4 h-4 sm:w-5 sm:h-5 text-gray-600" />
                <span className="text-xs sm:text-sm font-medium text-gray-700 w-12 sm:w-16">Volume: {volume}%</span>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={volume}
                  onChange={(e) => setVolume(parseInt(e.target.value))}
                  className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Quick Commands */}
          <div className="bg-white p-4 sm:p-6 rounded-3xl shadow-clay-soft">
            <h3 className="text-base sm:text-lg font-bold text-gray-800 mb-4">Quick Commands</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3">
              <button
                onClick={() => handleVoiceCommand('repeatLine')}
                className="p-2 sm:p-3 rounded-2xl bg-gradient-to-br from-blue-200 to-blue-300 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300 text-blue-700 text-xs sm:text-sm font-medium mobile-touch-target"
              >
                Restart
              </button>
              <button
                onClick={() => handleVoiceCommand('slowDown')}
                className="p-2 sm:p-3 rounded-2xl bg-gradient-to-br from-green-200 to-green-300 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300 text-green-700 text-xs sm:text-sm font-medium mobile-touch-target"
              >
                Slow Down
              </button>
              <button
                onClick={() => handleVoiceCommand('speedUp')}
                className="p-2 sm:p-3 rounded-2xl bg-gradient-to-br from-yellow-200 to-yellow-300 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300 text-yellow-700 text-xs sm:text-sm font-medium mobile-touch-target"
              >
                Speed Up
              </button>
              <button
                onClick={stop}
                className="p-2 sm:p-3 rounded-2xl bg-gradient-to-br from-red-200 to-red-300 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300 text-red-700 text-xs sm:text-sm font-medium mobile-touch-target"
              >
                Stop
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReaderPage;