import { GOOGLE_CLOUD_API_KEY, API_ENDPOINTS, EMOTION_STYLES } from '../config/constants';
import { TTSSettings, APIResponse } from '../types';

class GoogleCloudService {
  private apiKey: string;

  constructor() {
    this.apiKey = GOOGLE_CLOUD_API_KEY;
  }

  async extractTextFromImage(imageBase64: string): Promise<APIResponse> {
    try {
      const response = await fetch(`${API_ENDPOINTS.VISION}?key=${this.apiKey}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          requests: [{
            image: { content: imageBase64 },
            features: [
              { type: 'TEXT_DETECTION', maxResults: 1 },
              { type: 'DOCUMENT_TEXT_DETECTION', maxResults: 1 }
            ]
          }]
        })
      });

      const data = await response.json();
      
      if (data.responses && data.responses[0].textAnnotations) {
        const extractedText = data.responses[0].textAnnotations[0].description;
        return { success: true, data: extractedText };
      }
      
      return { success: false, error: 'No text found in image' };
    } catch (error) {
      return { success: false, error: `OCR failed: ${error}` };
    }
  }

  async textToSpeech(text: string, settings: TTSSettings): Promise<APIResponse> {
    try {
      const emotionStyle = EMOTION_STYLES[settings.emotion];
      
      // Create SSML with emotion awareness
      const ssmlText = `
        <speak>
          <prosody rate="${emotionStyle.rate}" pitch="${emotionStyle.pitch}" volume="${emotionStyle.volume}">
            <emphasis level="${emotionStyle.emphasis}">
              ${text}
            </emphasis>
          </prosody>
        </speak>
      `;

      const response = await fetch(`${API_ENDPOINTS.TEXT_TO_SPEECH}?key=${this.apiKey}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          input: { ssml: ssmlText },
          voice: {
            languageCode: settings.language,
            name: settings.voice
          },
          audioConfig: {
            audioEncoding: 'MP3',
            speakingRate: settings.speed,
            pitch: settings.pitch
          }
        })
      });

      const data = await response.json();
      
      if (data.audioContent) {
        const audioBlob = new Blob([Uint8Array.from(atob(data.audioContent), c => c.charCodeAt(0))], 
          { type: 'audio/mp3' });
        const audioUrl = URL.createObjectURL(audioBlob);
        return { success: true, data: audioUrl };
      }
      
      return { success: false, error: 'Failed to generate audio' };
    } catch (error) {
      return { success: false, error: `TTS failed: ${error}` };
    }
  }

  async speechToText(audioBlob: Blob): Promise<APIResponse> {
    try {
      const base64Audio = await this.blobToBase64(audioBlob);
      
      const response = await fetch(`${API_ENDPOINTS.SPEECH_TO_TEXT}?key=${this.apiKey}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          config: {
            encoding: 'WEBM_OPUS',
            sampleRateHertz: 48000,
            languageCode: 'en-US',
            enableAutomaticPunctuation: true
          },
          audio: { content: base64Audio }
        })
      });

      const data = await response.json();
      
      if (data.results && data.results[0]) {
        const transcript = data.results[0].alternatives[0].transcript;
        return { success: true, data: transcript };
      }
      
      return { success: false, error: 'No speech recognized' };
    } catch (error) {
      return { success: false, error: `Speech recognition failed: ${error}` };
    }
  }

  async explainImage(imageBase64: string): Promise<APIResponse> {
    try {
      // This would use Vertex AI Gemini for multimodal reasoning
      // For demo purposes, we'll combine OCR with a simple explanation
      const ocrResult = await this.extractTextFromImage(imageBase64);
      
      if (ocrResult.success) {
        const explanation = `This appears to be a document or image containing text. The content includes: ${ocrResult.data}. 
        This seems to be educational material that can be read aloud for better understanding.`;
        return { success: true, data: explanation };
      }
      
      return { success: false, error: 'Could not analyze image content' };
    } catch (error) {
      return { success: false, error: `Image analysis failed: ${error}` };
    }
  }

  private async blobToBase64(blob: Blob): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        resolve(result.split(',')[1]);
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }
}

export default new GoogleCloudService();