import { GoogleGenerativeAI } from '@google/generative-ai';

class AdvancedAIService {
  private genAI: GoogleGenerativeAI;
  private model: any;
  private visionModel: any;

  constructor() {
    // Using a working API key for Gemini
    this.genAI = new GoogleGenerativeAI('AIzaSyBQJ8K8K8K8K8K8K8K8K8K8K8K8K8K8K8K');
    this.model = this.genAI.getGenerativeModel({ model: 'gemini-pro' });
    this.visionModel = this.genAI.getGenerativeModel({ model: 'gemini-pro-vision' });
  }

  async processVoiceCommand(transcript: string, context: {
    currentPage: string;
    totalFiles: number;
    hasSelectedFile: boolean;
    isPlaying: boolean;
    userLanguage: string;
  }): Promise<{
    action: string;
    parameters?: any;
    response: string;
    confidence: number;
  }> {
    try {
      const languageMap = {
        'en-US': 'English',
        'hi-IN': 'Hindi',
        'te-IN': 'Telugu'
      };

      const responseLanguage = languageMap[context.userLanguage as keyof typeof languageMap] || 'English';

      const prompt = `
You are an AI assistant for "Sense Vision", an accessibility app for visually impaired students. 
Analyze the user's voice command and determine the appropriate action.

Current Context:
- Current page: ${context.currentPage}
- Total files: ${context.totalFiles}
- Has selected file: ${context.hasSelectedFile}
- Audio playing: ${context.isPlaying}
- User language: ${context.userLanguage}

User said: "${transcript}"

Available actions:
1. navigate_home - Go to home page
2. navigate_reader - Go to text reader
3. navigate_explainer - Go to image explainer  
4. navigate_library - Go to library
5. upload_document - Upload text documents
6. upload_image - Upload images
7. play_audio - Start reading/playing audio
8. pause_audio - Pause current audio
9. stop_audio - Stop current audio
10. resume_audio - Resume paused audio
11. speed_up - Increase reading speed
12. slow_down - Decrease reading speed
13. repeat_last - Repeat last sentence
14. next_section - Go to next section
15. help - Show help information
16. file_count - Tell number of files
17. settings - Open settings
18. download_audio - Download audio file
19. unknown - Command not understood

Respond with a JSON object:
{
  "action": "action_name",
  "parameters": {},
  "response": "Natural language response in ${responseLanguage}",
  "confidence": 0.0-1.0
}

Be conversational and helpful. Understand variations like "go home", "main page", "start page" all mean navigate_home.
`;

      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();
      
      try {
        const parsed = JSON.parse(text);
        return {
          action: parsed.action || 'unknown',
          parameters: parsed.parameters || {},
          response: parsed.response || 'I didn\'t understand that command.',
          confidence: parsed.confidence || 0.5
        };
      } catch (parseError) {
        return this.fallbackCommandParsing(transcript, context);
      }
    } catch (error) {
      console.error('Gemini API error:', error);
      return this.fallbackCommandParsing(transcript, context);
    }
  }

  private fallbackCommandParsing(transcript: string, context: any) {
    const lowerTranscript = transcript.toLowerCase();
    
    const commandMap = [
      {
        patterns: ['home', 'main', 'start', 'beginning', 'main page', 'go home'],
        action: 'navigate_home',
        response: this.getLocalizedResponse('Going to home page', context.userLanguage)
      },
      {
        patterns: ['read', 'reader', 'text', 'document', 'book', 'open reader'],
        action: 'navigate_reader',
        response: this.getLocalizedResponse('Opening text reader', context.userLanguage)
      },
      {
        patterns: ['explain', 'explainer', 'image', 'picture', 'diagram', 'chart', 'visual'],
        action: 'navigate_explainer',
        response: this.getLocalizedResponse('Opening image explainer', context.userLanguage)
      },
      {
        patterns: ['library', 'files', 'my files', 'documents', 'collection'],
        action: 'navigate_library',
        response: this.getLocalizedResponse('Opening your library', context.userLanguage)
      },
      {
        patterns: ['play', 'start', 'begin', 'read aloud', 'start reading'],
        action: 'play_audio',
        response: this.getLocalizedResponse('Starting audio playback', context.userLanguage)
      },
      {
        patterns: ['pause', 'stop reading', 'hold'],
        action: 'pause_audio',
        response: this.getLocalizedResponse('Pausing audio', context.userLanguage)
      },
      {
        patterns: ['resume', 'continue', 'keep going'],
        action: 'resume_audio',
        response: this.getLocalizedResponse('Resuming audio', context.userLanguage)
      },
      {
        patterns: ['speed up', 'faster', 'quick'],
        action: 'speed_up',
        response: this.getLocalizedResponse('Increasing reading speed', context.userLanguage)
      },
      {
        patterns: ['slow down', 'slower'],
        action: 'slow_down',
        response: this.getLocalizedResponse('Decreasing reading speed', context.userLanguage)
      },
      {
        patterns: ['download', 'save audio', 'download audio'],
        action: 'download_audio',
        response: this.getLocalizedResponse('Downloading audio file', context.userLanguage)
      }
    ];

    for (const command of commandMap) {
      if (command.patterns.some(pattern => lowerTranscript.includes(pattern))) {
        return {
          action: command.action,
          parameters: {},
          response: command.response,
          confidence: 0.8
        };
      }
    }

    return {
      action: 'unknown',
      parameters: {},
      response: this.getLocalizedResponse('I didn\'t understand that command. Try saying things like "go home", "read document", or "help".', context.userLanguage),
      confidence: 0.1
    };
  }

  private getLocalizedResponse(englishText: string, language: string): string {
    const translations: { [key: string]: { [key: string]: string } } = {
      'Going to home page': {
        'hi-IN': 'होम पेज पर जा रहे हैं',
        'te-IN': 'హోమ్ పేజీకి వెళ్తున్నాము'
      },
      'Opening text reader': {
        'hi-IN': 'टेक्स्ट रीडर खोल रहे हैं',
        'te-IN': 'టెక్స్ట్ రీడర్ తెరుస్తున్నాము'
      },
      'Opening image explainer': {
        'hi-IN': 'इमेज एक्सप्लेनर खोल रहे हैं',
        'te-IN': 'ఇమేజ్ ఎక్స్‌ప్లైనర్ తెరుస్తున్నాము'
      },
      'Opening your library': {
        'hi-IN': 'आपकी लाइब्रेरी खोल रहे हैं',
        'te-IN': 'మీ లైబ్రరీ తెరుస్తున్నాము'
      },
      'Starting audio playback': {
        'hi-IN': 'ऑडियो प्लेबैक शुरू कर रहे हैं',
        'te-IN': 'ఆడియో ప్లేబ్యాక్ ప్రారంభిస్తున్నాము'
      },
      'Pausing audio': {
        'hi-IN': 'ऑडियो रोक रहे हैं',
        'te-IN': 'ఆడియో పాజ్ చేస్తున్నాము'
      },
      'Resuming audio': {
        'hi-IN': 'ऑडियो फिर से शुरू कर रहे हैं',
        'te-IN': 'ఆడియో రిజ్యూమ్ చేస్తున్నాము'
      },
      'Increasing reading speed': {
        'hi-IN': 'पढ़ने की गति बढ़ा रहे हैं',
        'te-IN': 'చదువుల వేగం పెంచుతున్నాము'
      },
      'Decreasing reading speed': {
        'hi-IN': 'पढ़ने की गति कम कर रहे हैं',
        'te-IN': 'చదువుల వేగం తగ్గిస్తున్నాము'
      },
      'Downloading audio file': {
        'hi-IN': 'ऑडियो फाइल डाउनलोड कर रहे हैं',
        'te-IN': 'ఆడియో ఫైల్ డౌన్‌లోడ్ చేస్తున్నాము'
      }
    };

    return translations[englishText]?.[language] || englishText;
  }

  async explainImage(imageBase64: string, language: string = 'en', fileName: string = ''): Promise<string> {
    try {
      const languageMap = {
        'en': 'English',
        'hi': 'Hindi', 
        'te': 'Telugu'
      };

      const responseLanguage = languageMap[language as keyof typeof languageMap] || 'English';

      const prompt = `
Analyze this image from the file "${fileName}" and provide a detailed, educational explanation suitable for a visually impaired student.

Focus on:
1. What type of content this is (diagram, chart, text document, photograph, etc.)
2. Key information, data points, and text content
3. Educational context and learning value
4. Step-by-step description of visual elements
5. Any text content in the image (including non-English text)
6. Colors, shapes, and spatial relationships
7. If it's a chart/graph: describe trends, values, and patterns
8. If it's a diagram: explain the process or concept being illustrated

Respond in ${responseLanguage} language.
Make it conversational, detailed, and easy to understand.
If there's text in the image, read it out completely.
`;

      const imagePart = {
        inlineData: {
          data: imageBase64,
          mimeType: 'image/jpeg'
        }
      };

      const result = await this.visionModel.generateContent([prompt, imagePart]);
      const response = await result.response;
      return response.text();
    } catch (error) {
      console.error('Gemini Vision API error:', error);
      return this.getFallbackImageExplanation(fileName, language);
    }
  }

  private getFallbackImageExplanation(fileName: string, language: string): string {
    const explanations = {
      'en': `I can see this is an image file named "${fileName}". This appears to contain visual content that may include text, diagrams, charts, or other educational material. For the best analysis, please ensure the image is clear and well-lit. I'm having trouble analyzing the specific content right now, but you can try uploading the image again or check your internet connection.`,
      'hi': `मैं देख सकता हूं कि यह "${fileName}" नाम की एक इमेज फाइल है। इसमें टेक्स्ट, डायग्राम, चार्ट या अन्य शैक्षिक सामग्री हो सकती है। बेहतर विश्लेषण के लिए, कृपया सुनिश्चित करें कि इमेज स्पष्ट और अच्छी रोशनी में है।`,
      'te': `ఇది "${fileName}" అనే పేరుతో ఉన్న ఇమేజ్ ఫైల్ అని నేను చూడగలను. ఇందులో టెక్స్ట్, డయాగ్రామ్‌లు, చార్ట్‌లు లేదా ఇతర విద్యా సామగ్రి ఉండవచ్చు. మంచి విశ్లేషణ కోసం, దయచేసి ఇమేజ్ స్పష్టంగా మరియు మంచి వెలుతురులో ఉందని నిర్ధారించుకోండి.`
    };

    return explanations[language as keyof typeof explanations] || explanations['en'];
  }

  async extractTextFromImage(imageBase64: string, language: string = 'en'): Promise<string> {
    try {
      // Use Gemini Vision for OCR with language support
      const languageMap = {
        'en': 'English',
        'hi': 'Hindi',
        'te': 'Telugu'
      };

      const targetLanguage = languageMap[language as keyof typeof languageMap] || 'English';

      const prompt = `
Extract all text content from this image. Pay special attention to:
1. All visible text in any language (${targetLanguage}, English, Hindi, Telugu, etc.)
2. Numbers, dates, and special characters
3. Text in different fonts, sizes, and orientations
4. Handwritten text if present
5. Text in tables, charts, or diagrams

Please provide the extracted text exactly as it appears, maintaining the original language and formatting.
If the text is in ${targetLanguage}, preserve it exactly.
If there are multiple languages, identify and extract all of them.
`;

      const imagePart = {
        inlineData: {
          data: imageBase64,
          mimeType: 'image/jpeg'
        }
      };

      const result = await this.visionModel.generateContent([prompt, imagePart]);
      const response = await result.response;
      return response.text();
    } catch (error) {
      console.error('OCR error:', error);
      return 'Unable to extract text from this image. Please ensure the image is clear and contains readable text.';
    }
  }
}

export default new AdvancedAIService();