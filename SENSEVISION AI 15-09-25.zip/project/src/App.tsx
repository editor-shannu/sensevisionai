import React, { useState, useCallback, useEffect } from 'react';
import { Settings, Home, BookOpen, Brain, Library } from 'lucide-react';
import AIVoiceAssistant from './components/AIVoiceAssistant';
import SimpleNavigation from './components/SimpleNavigation';
import HomePage from './components/HomePage';
import ReaderPage from './components/ReaderPage';
import ExplainerPage from './components/ExplainerPage';
import LibraryPage from './components/LibraryPage';
import SettingsModal from './components/SettingsModal';
import { StudyFile } from './types';
import enhancedFileProcessingService from './services/enhancedFileProcessingService';
import { useTextToSpeech } from './hooks/useTextToSpeech';
import { Toaster } from 'react-hot-toast';

function App() {
  const [currentPage, setCurrentPage] = useState<'home' | 'reader' | 'explainer' | 'library'>('home');
  const [files, setFiles] = useState<StudyFile[]>([]);
  const [selectedFile, setSelectedFile] = useState<StudyFile | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  const {
    speak,
    pause,
    resume,
    stop,
    isPlaying: ttsIsPlaying,
    adjustSpeed
  } = useTextToSpeech();

  // Load saved files from localStorage on component mount
  useEffect(() => {
    const savedFiles = localStorage.getItem('senseVisionFiles');
    if (savedFiles) {
      try {
        const parsedFiles = JSON.parse(savedFiles);
        setFiles(parsedFiles.map((file: any) => ({
          ...file,
          uploadedAt: new Date(file.uploadedAt)
        })));
      } catch (error) {
        console.error('Error loading saved files:', error);
      }
    }
  }, []);

  // Save files to localStorage whenever files change
  useEffect(() => {
    if (files.length > 0) {
      localStorage.setItem('senseVisionFiles', JSON.stringify(files));
    }
  }, [files]);

  const handleFileUpload = useCallback(async (uploadedFiles: File[], type: 'text' | 'visual') => {
    setIsProcessing(true);
    
    for (const file of uploadedFiles) {
      try {
        const result = await enhancedFileProcessingService.processFile(file);
        
        if (result.success) {
          const processedFile = result.data as StudyFile;
          processedFile.contentType = type;
          
          setFiles(prev => [...prev, processedFile]);
          
          // Auto-redirect to reader and start reading for text files
          if (type === 'text') {
            setSelectedFile(processedFile);
            setCurrentPage('reader');
            // Auto-start reading after a short delay
            setTimeout(() => {
              if (processedFile.content) {
                speak(processedFile.content);
              }
            }, 2000);
          } else {
            // For visual files, redirect to explainer
            setSelectedFile(processedFile);
            setCurrentPage('explainer');
          }
        }
      } catch (error) {
        console.error('File processing error:', error);
      }
    }
    
    setIsProcessing(false);
  }, []);

  const handleFileSelect = useCallback((file: StudyFile) => {
    setSelectedFile(file);
    if (file.contentType === 'visual') {
      setCurrentPage('explainer');
    } else {
      setCurrentPage('reader');
    }
  }, []);

  const handleFileDelete = useCallback((fileId: string) => {
    setFiles(prev => prev.filter(f => f.id !== fileId));
    if (selectedFile?.id === fileId) {
      setSelectedFile(null);
      setCurrentPage('library');
    }
  }, [selectedFile]);

  const handleDownloadAudio = useCallback(() => {
    if (selectedFile?.content) {
      // Generate and download audio file
      const settings = {
        language: 'en-US', // Get from user settings
        voice: 'default',
        speed: 1.0,
        pitch: 0,
        emotion: 'academic' as const
      };
      
      // Use browser TTS to generate audio
      if ('speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(selectedFile.content);
        utterance.lang = settings.language;
        utterance.rate = settings.speed;
        
        // Create a simple audio file (placeholder implementation)
        const blob = new Blob([selectedFile.content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${selectedFile.name}_content.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        speak('Audio content downloaded as text file.');
      }
    }
  }, [selectedFile]);
  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'home':
        return (
          <HomePage
            onFileUpload={handleFileUpload}
            isProcessing={isProcessing}
            onNavigate={setCurrentPage}
            totalFiles={files.length}
          />
        );
      case 'reader':
        return (
          <ReaderPage
            files={files.filter(f => f.contentType === 'text')}
            selectedFile={selectedFile}
            onFileSelect={handleFileSelect}
          />
        );
      case 'explainer':
        return (
          <ExplainerPage
            files={files.filter(f => f.contentType === 'visual')}
            selectedFile={selectedFile}
            onFileSelect={handleFileSelect}
          />
        );
      case 'library':
        return (
          <LibraryPage
            files={files}
            onFileSelect={handleFileSelect}
            onFileDelete={handleFileDelete}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      {/* Header */}
      <header className="flex items-center justify-between p-4 sm:p-6 bg-white/80 backdrop-blur-sm">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-800">Sense Vision</h1>
          <p className="text-xs sm:text-sm text-gray-600">AI Learning Companion</p>
        </div>
        <button 
          onClick={() => setShowSettings(true)}
          className="p-3 rounded-2xl bg-gradient-to-br from-purple-200 to-purple-300 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300 mobile-touch-target"
        >
          <Settings className="w-5 h-5 sm:w-6 sm:h-6 text-purple-700" />
        </button>
      </header>

      {/* Main Content */}
      <main className="flex-1 pb-24 sm:pb-28">
        {renderCurrentPage()}
      </main>

      {/* Animated Navigation */}
      <SimpleNavigation 
        currentPage={currentPage}
        onNavigate={setCurrentPage}
      />

      {/* Settings Modal */}
      <SettingsModal 
        isOpen={showSettings} 
        onClose={() => setShowSettings(false)} 
      />

      {/* AI Voice Assistant */}
      <AIVoiceAssistant 
        onNavigate={setCurrentPage}
        onFileUpload={handleFileUpload}
        totalFiles={files.length}
        currentPage={currentPage}
        hasSelectedFile={selectedFile !== null}
        isPlaying={ttsIsPlaying}
        onPlayAudio={() => {
          if (selectedFile?.content) {
            speak(selectedFile.content);
          }
        }}
        onPauseAudio={pause}
        onStopAudio={stop}
        onResumeAudio={resume}
        onSpeedUp={() => adjustSpeed(0.1)}
        onSlowDown={() => adjustSpeed(-0.1)}
        onRepeatLast={() => {
          if (selectedFile?.content) {
            const sentences = selectedFile.content.split(/[.!?]+/);
            if (sentences.length > 0) {
              speak(sentences[sentences.length - 1]);
            }
          }
        }}
        onNextSection={() => {
          // Implementation for next section
          if (selectedFile?.content) {
            speak("Moving to next section");
          }
        }}
        onOpenSettings={() => setShowSettings(true)}
        onDownloadAudio={handleDownloadAudio}
      />
      
      {/* Toast Notifications */}
      <Toaster 
        position="top-center"
        toastOptions={{
          duration: 3000,
          style: {
            background: '#fff',
            color: '#333',
            borderRadius: '12px',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
          },
        }}
      />
    </div>
  );
}

export default App;