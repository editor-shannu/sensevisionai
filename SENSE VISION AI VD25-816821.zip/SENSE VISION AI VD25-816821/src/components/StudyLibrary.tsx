import React from 'react';
import { StudyFile } from '../types';
import { FileText, Image, Music, Trash2, Play, Pause } from 'lucide-react';
import { formatFileSize, formatDate } from '../utils/helpers';

interface StudyLibraryProps {
  files: StudyFile[];
  onFileSelect: (file: StudyFile) => void;
  onFileDelete: (fileId: string) => void;
  onPlayAudio: (file: StudyFile) => void;
  isPlaying: boolean;
  currentFileId?: string;
}

const StudyLibrary: React.FC<StudyLibraryProps> = ({
  files,
  onFileSelect,
  onFileDelete,
  onPlayAudio,
  isPlaying,
  currentFileId
}) => {
  const getFileIcon = (type: string) => {
    if (type.startsWith('image/')) return Image;
    if (type.includes('pdf') || type.includes('document') || type.includes('text')) return FileText;
    return FileText;
  };

  const getStatusColor = (status: StudyFile['status']) => {
    switch (status) {
      case 'ready': return 'from-green-100 to-green-200 border-green-200';
      case 'processing': return 'from-yellow-100 to-yellow-200 border-yellow-200';
      case 'error': return 'from-red-100 to-red-200 border-red-200';
      default: return 'from-gray-100 to-gray-200 border-gray-200';
    }
  };

  if (files.length === 0) {
    return (
      <div className="text-center py-16">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-gray-100 to-gray-200 shadow-clay-soft mb-6">
          <FileText className="w-10 h-10 text-gray-400" />
        </div>
        <h3 className="text-xl font-bold text-gray-700 mb-2">No Study Materials Yet</h3>
        <p className="text-gray-500">Upload your first document to get started</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Your Study Library</h2>
      
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {files.map((file) => {
          const Icon = getFileIcon(file.type);
          const statusColor = getStatusColor(file.status);
          const isCurrentlyPlaying = isPlaying && currentFileId === file.id;
          
          return (
            <div
              key={file.id}
              className={`relative p-6 rounded-3xl border-2 shadow-clay-soft hover:shadow-clay-hover transition-all duration-300 cursor-pointer bg-gradient-to-br ${statusColor}`}
              onClick={() => onFileSelect(file)}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="p-3 rounded-2xl bg-white shadow-clay-inset">
                    <Icon className="w-6 h-6 text-gray-700" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-800 truncate" title={file.name}>
                      {file.name}
                    </h3>
                    <p className="text-sm text-gray-600">
                      {formatFileSize(file.size)} • {formatDate(file.uploadedAt)}
                    </p>
                  </div>
                </div>
                
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onFileDelete(file.id);
                  }}
                  className="p-2 rounded-xl bg-red-100 hover:bg-red-200 shadow-clay-soft hover:shadow-clay-inset transition-all duration-200"
                  aria-label={`Delete ${file.name}`}
                >
                  <Trash2 className="w-4 h-4 text-red-600" />
                </button>
              </div>
              
              {file.summary && (
                <p className="text-sm text-gray-600 mb-4 line-clamp-3">
                  {file.summary}
                </p>
              )}
              
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className={`w-3 h-3 rounded-full ${
                    file.status === 'ready' ? 'bg-green-500' :
                    file.status === 'processing' ? 'bg-yellow-500 animate-pulse' :
                    'bg-red-500'
                  }`}></div>
                  <span className="text-sm font-medium capitalize text-gray-700">
                    {file.status}
                  </span>
                </div>
                
                {file.status === 'ready' && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onPlayAudio(file);
                    }}
                    className="flex items-center space-x-2 px-4 py-2 rounded-xl bg-white shadow-clay-soft hover:shadow-clay-inset transition-all duration-200"
                    aria-label={isCurrentlyPlaying ? 'Pause reading' : 'Start reading'}
                  >
                    {isCurrentlyPlaying ? (
                      <>
                        <Pause className="w-4 h-4 text-purple-600" />
                        <span className="text-sm font-medium text-purple-600">Pause</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4 text-purple-600" />
                        <span className="text-sm font-medium text-purple-600">Read</span>
                      </>
                    )}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default StudyLibrary;