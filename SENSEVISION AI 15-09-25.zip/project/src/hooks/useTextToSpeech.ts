import { useState, useCallback, useRef } from 'react';
import { TTSSettings } from '../types';
import googleCloudService from '../services/googleCloudService';

export const useTextToSpeech = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentPosition, setCurrentPosition] = useState(0);
  const [settings, setSettings] = useState<TTSSettings>({
    language: 'en-US',
    voice: 'en-US-Standard-A',
    speed: 1.0,
    pitch: 0,
    emotion: 'academic'
  });
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const currentTextRef = useRef<string>('');
  const sentencesRef = useRef<string[]>([]);

  const speak = useCallback(async (text: string) => {
    try {
      // Use browser's built-in speech synthesis for immediate functionality
      if ('speechSynthesis' in window) {
        // Stop any current speech
        speechSynthesis.cancel();
        
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = settings.language;
        utterance.rate = settings.speed;
        utterance.pitch = settings.pitch / 10; // Convert to 0-2 range
        
        // Get the best voice for the selected language
        const voices = speechSynthesis.getVoices();
        const preferredVoice = voices.find(voice => 
          voice.lang === settings.language && voice.localService
        ) || voices.find(voice => voice.lang === settings.language) ||
           voices.find(voice => voice.lang.startsWith(settings.language.split('-')[0]));
        
        if (preferredVoice) {
          utterance.voice = preferredVoice;
        }
        
        utterance.onstart = () => setIsPlaying(true);
        utterance.onend = () => {
          setIsPlaying(false);
          setCurrentPosition(0);
        };
        utterance.onerror = () => {
          setIsPlaying(false);
          setCurrentPosition(0);
        };
        
        speechSynthesis.speak(utterance);
        currentTextRef.current = text;
        sentencesRef.current = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
      }
    } catch (error) {
      console.error('TTS Error:', error);
    }
  }, [settings]);

  const pause = useCallback(() => {
    if ('speechSynthesis' in window) {
      speechSynthesis.pause();
      setIsPlaying(false);
    }
  }, []);

  const resume = useCallback(() => {
    if ('speechSynthesis' in window) {
      speechSynthesis.resume();
      setIsPlaying(true);
    }
  }, []);

  const stop = useCallback(() => {
    if ('speechSynthesis' in window) {
      speechSynthesis.cancel();
    }
    setIsPlaying(false);
    setCurrentPosition(0);
  }, []);

  const repeatLastSentence = useCallback(() => {
    if (sentencesRef.current.length > 0 && currentPosition > 0) {
      const sentence = sentencesRef.current[Math.max(0, currentPosition - 1)];
      speak(sentence);
    }
  }, [currentPosition, speak]);

  const adjustSpeed = useCallback((delta: number) => {
    setSettings(prev => ({
      ...prev,
      speed: Math.max(0.5, Math.min(2.0, prev.speed + delta))
    }));
  }, []);

  return {
    speak,
    pause,
    resume,
    stop,
    repeatLastSentence,
    adjustSpeed,
    isPlaying,
    settings,
    setSettings,
    currentPosition
  };
};