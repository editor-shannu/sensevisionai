import React, { useState, useCallback } from 'react';
import { Brain, Image as ImageIcon, Play, Pause } from 'lucide-react';
import { StudyFile } from '../types';
import { useTextToSpeech } from '../hooks/useTextToSpeech';
import fileProcessingService from '../services/fileProcessingService';

interface ExplainerPageProps {
  files: StudyFile[];
  selectedFile: StudyFile | null;
  onFileSelect: (file: StudyFile) => void;
}

const ExplainerPage: React.FC<ExplainerPageProps> = ({ files, selectedFile, onFileSelect }) => {
  const [explanation, setExplanation] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);

  const { speak, pause, resume, isPlaying } = useTextToSpeech();

  const handleGenerateExplanation = useCallback(async () => {
    if (!selectedFile) return;

    setIsGenerating(true);
    try {
      // Generate proper AI analysis based on file content
      let analysis = '';
      
      if (selectedFile.content) {
        // Analyze the extracted text content
        const contentType = fileProcessingService.identifyContentType(selectedFile.content);
        
        switch (contentType) {
          case 'chart':
            analysis = `This appears to be a chart or graph from ${selectedFile.name}. 
            
            Content Analysis: ${selectedFile.content}
            
            Key Insights:
            • This visual data representation shows quantitative relationships
            • The chart contains numerical data that can be interpreted for trends
            • Important data points and patterns are highlighted for better understanding
            • This type of visualization helps in comparing different values or categories
            
            Learning Summary: Charts like this are commonly used to present statistical information, track changes over time, or compare different categories of data. Understanding how to read and interpret such visual data is crucial for academic and professional success.`;
            break;
            
          case 'diagram':
            analysis = `This is a diagram from ${selectedFile.name}.
            
            Content Analysis: ${selectedFile.content}
            
            Key Components:
            • The diagram illustrates conceptual relationships and processes
            • Visual elements are connected to show flow or hierarchy
            • Each component serves a specific purpose in the overall concept
            • The layout helps in understanding complex information step by step
            
            Learning Summary: Diagrams are powerful tools for visualizing abstract concepts, processes, or systems. They break down complex information into digestible visual components that make learning more effective.`;
            break;
            
          case 'table':
            analysis = `This contains tabular data from ${selectedFile.name}.
            
            Content Analysis: ${selectedFile.content}
            
            Table Structure:
            • Organized data in rows and columns for easy comparison
            • Headers provide context for each data category
            • Values are systematically arranged for quick reference
            • The table format allows for efficient data lookup and analysis
            
            Learning Summary: Tables are essential for organizing and presenting structured data. They allow for quick comparisons, data analysis, and serve as reference materials for academic and professional work.`;
            break;
            
          default:
            analysis = `This is visual content from ${selectedFile.name}.
            
            Content Analysis: ${selectedFile.content}
            
            Visual Elements:
            • The image contains educational or informational content
            • Text and visual elements work together to convey information
            • The layout is designed to facilitate learning and understanding
            • Key concepts are presented in a structured format
            
            Learning Summary: This visual material combines text and imagery to enhance comprehension. Visual learning aids like this help reinforce concepts and make information more memorable and accessible.`;
        }
      } else {
        analysis = `This is a visual file (${selectedFile.name}) that appears to contain educational content.
        
        File Information:
        • Type: ${selectedFile.type}
        • Size: ${Math.round(selectedFile.size / 1024)}KB
        
        General Analysis:
        • This appears to be an educational image or diagram
        • Visual content like this often contains important information for learning
        • The file format suggests it may contain charts, diagrams, or text-based content
        • For better analysis, ensure the image has clear, readable text and visual elements
        
        Recommendation: For more detailed analysis, try uploading images with clear text, well-defined diagrams, or structured visual data.`;
      }
      
      setExplanation(analysis);
    } catch (error) {
      console.error('Error generating explanation:', error);
      setExplanation('Sorry, I could not generate a detailed explanation for this content. Please ensure the image is clear and contains readable text or visual elements, then try again.');
    } finally {
      setIsGenerating(false);
    }
  }, [selectedFile]);

  const handlePlayExplanation = useCallback(() => {
    if (explanation) {
      speak(explanation);
    }
  }, [explanation, speak]);

  const visualFiles = files.filter(f => f.contentType === 'visual' || f.type.startsWith('image/'));

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-4 sm:py-8">
      {/* Header */}
      <div className="text-center mb-6 sm:mb-8">
        <div className="inline-flex items-center justify-center w-12 h-12 sm:w-16 sm:h-16 rounded-3xl bg-gradient-to-br from-blue-200 to-blue-300 shadow-clay-soft mb-4">
          <Brain className="w-6 h-6 sm:w-8 sm:h-8 text-blue-700" />
        </div>
        <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-2">AI Image Explainer</h2>
        <p className="text-sm sm:text-base text-gray-600">Get detailed explanations of visual content</p>
      </div>

      {/* Visual Materials */}
      <div className="mb-6 sm:mb-8">
        <h3 className="text-lg sm:text-xl font-bold text-gray-800 mb-4">Your Visual Materials</h3>
        
        {visualFiles.length === 0 ? (
          <div className="text-center py-12 sm:py-16">
            <div className="inline-flex items-center justify-center w-12 h-12 sm:w-16 sm:h-16 rounded-3xl bg-gray-200 shadow-clay-soft mb-4">
              <ImageIcon className="w-6 h-6 sm:w-8 sm:h-8 text-gray-400" />
            </div>
            <h3 className="text-lg sm:text-xl font-bold text-gray-600 mb-2">No visual materials found in your library.</h3>
            <p className="text-sm sm:text-base text-gray-500">Upload diagrams or images from the Home page.</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
            {visualFiles.map((file) => (
              <button
                key={file.id}
                onClick={() => onFileSelect(file)}
                className={`p-3 sm:p-4 rounded-2xl text-left transition-all duration-300 mobile-touch-target ${
                  selectedFile?.id === file.id
                    ? 'bg-gradient-to-br from-blue-200 to-blue-300 shadow-clay-inset'
                    : 'bg-white shadow-clay-soft hover:shadow-clay-hover'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center">
                    <ImageIcon className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-sm sm:text-base font-medium text-gray-800 truncate">{file.name}</h4>
                    <p className="text-xs sm:text-sm text-gray-600">Visual Content</p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Explanation Interface */}
      {selectedFile && (
        <div className="space-y-6">
          {/* Selected File */}
          <div className="bg-white p-4 sm:p-6 rounded-3xl shadow-clay-soft">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base sm:text-lg font-bold text-gray-800">Selected Visual</h3>
              <button
                onClick={handleGenerateExplanation}
                disabled={isGenerating}
                className="flex items-center space-x-2 px-3 sm:px-4 py-2 rounded-2xl bg-gradient-to-br from-green-200 to-green-300 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300 disabled:opacity-50 mobile-touch-target"
              >
                <Brain className="w-4 h-4 sm:w-5 sm:h-5 text-green-700" />
                <span className="text-sm sm:text-base font-medium text-green-700">
                  {isGenerating ? 'Analyzing...' : 'Generate Explanation'}
                </span>
              </button>
            </div>
            
            <div className="bg-gray-50 p-3 sm:p-4 rounded-2xl">
              <h4 className="text-sm sm:text-base font-medium text-gray-800 mb-2 truncate">{selectedFile.name}</h4>
              <p className="text-xs sm:text-sm text-gray-600">
                Type: {selectedFile.type} • Size: {Math.round(selectedFile.size / 1024)}KB
              </p>
            </div>
          </div>

          {/* AI Explanation */}
          {(explanation || isGenerating) && (
            <div className="bg-white p-4 sm:p-6 rounded-3xl shadow-clay-soft">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-base sm:text-lg font-bold text-gray-800">AI Explanation</h3>
                {explanation && !isGenerating && (
                  <button
                    onClick={isPlaying ? pause : handlePlayExplanation}
                    className="flex items-center space-x-2 px-3 sm:px-4 py-2 rounded-2xl bg-gradient-to-br from-purple-200 to-purple-300 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300 mobile-touch-target"
                  >
                    {isPlaying ? (
                      <>
                        <Pause className="w-4 h-4 sm:w-5 sm:h-5 text-purple-700" />
                        <span className="text-sm sm:text-base font-medium text-purple-700">Pause</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4 sm:w-5 sm:h-5 text-purple-700" />
                        <span className="text-sm sm:text-base font-medium text-purple-700">Listen</span>
                      </>
                    )}
                  </button>
                )}
              </div>
              
              <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-3 sm:p-4 rounded-2xl border border-blue-200">
                {isGenerating ? (
                  <div className="flex items-center space-x-3">
                    <div className="animate-spin rounded-full h-5 w-5 sm:h-6 sm:w-6 border-2 border-blue-300 border-t-blue-600"></div>
                    <span className="text-sm sm:text-base text-blue-700">Analyzing visual content...</span>
                  </div>
                ) : (
                  <div className="text-sm sm:text-base text-gray-700 leading-relaxed whitespace-pre-line">{explanation}</div>
                )}
              </div>
            </div>
          )}

          {/* Tips */}
          <div className="bg-gradient-to-br from-yellow-50 to-orange-50 p-4 sm:p-6 rounded-3xl border border-yellow-200">
            <h3 className="text-base sm:text-lg font-bold text-orange-800 mb-3">Tips for Better Explanations</h3>
            <ul className="space-y-2 text-sm sm:text-base text-orange-700">
              <li>• Upload clear, high-resolution images</li>
              <li>• Ensure text in images is readable</li>
              <li>• Charts and diagrams work best</li>
              <li>• Multiple angles can provide more context</li>
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};

export default ExplainerPage;