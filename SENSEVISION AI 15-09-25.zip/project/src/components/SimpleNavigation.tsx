import React from 'react';
import { Home, BookOpen, Brain, Library } from 'lucide-react';

interface SimpleNavigationProps {
  currentPage: 'home' | 'reader' | 'explainer' | 'library';
  onNavigate: (page: 'home' | 'reader' | 'explainer' | 'library') => void;
}

const SimpleNavigation: React.FC<SimpleNavigationProps> = ({ currentPage, onNavigate }) => {
  const navItems = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'reader', icon: BookOpen, label: 'Reader' },
    { id: 'explainer', icon: Brain, label: 'Explainer' },
    { id: 'library', icon: Library, label: 'Library' }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg z-50">
      <div className="max-w-md mx-auto px-4">
        <div className="flex justify-around items-center py-2">
          {navItems.map(({ id, icon: Icon, label }) => (
            <button
              key={id}
              onClick={() => onNavigate(id as any)}
              className={`flex flex-col items-center py-2 px-3 rounded-lg transition-colors duration-200 ${
                currentPage === id
                  ? 'text-purple-600 bg-purple-50'
                  : 'text-gray-600 hover:text-purple-600 hover:bg-gray-50'
              }`}
            >
              <Icon className="w-6 h-6 mb-1" />
              <span className="text-xs font-medium">{label}</span>
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
};

export default SimpleNavigation;