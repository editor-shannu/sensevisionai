import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Mic, MicOff, Volume2, VolumeX, MessageCircle } from 'lucide-react';

interface AIVoiceAssistantProps {
  onNavigate: (page: 'home' | 'reader' | 'explainer' | 'library') => void;
  onFileUpload: (files: File[], type: 'text' | 'visual') => void;
  totalFiles: number;
}

const AIVoiceAssistant: React.FC<AIVoiceAssistantProps> = ({ 
  onNavigate, 
  onFileUpload, 
  totalFiles 
}) => {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isActive, setIsActive] = useState(true);
  const [userLanguage, setUserLanguage] = useState('en-US');
  const [hasGreeted, setHasGreeted] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [isLanguageSet, setIsLanguageSet] = useState(false);
  
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const speechTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const startListeningRef = useRef<(() => void) | null>(null);
  const isStartingRef = useRef(false); // NEW: tracks if recognition is starting

  // Initialize speech recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognition = new SpeechRecognition();

      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = userLanguage;
      recognition.maxAlternatives = 1;

      recognition.onstart = () => setIsListening(true);

      recognition.onresult = (event) => {
        const result = event.results[0][0];
        const confidence = result.confidence;
        const transcript = result.transcript.toLowerCase().trim();

        if (confidence > 0.7) {
          setTranscript(transcript);
          handleVoiceCommand(transcript);
        } else {
          speak(getResponse('not_clear'));
        }
      };

      recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);

        if (event.error === 'no-speech') {
          speak(getResponse('no_speech'));
          try { recognition.stop(); } catch (e) {}
          setTimeout(() => {
            if (isActive && !isSpeaking) startListeningRef.current?.();
          }, 1500);
        }
      };

      recognition.onend = () => {
        setIsListening(false);
        isStartingRef.current = false; // reset starting flag on end
        if (isActive && isLanguageSet) {
          speechTimeoutRef.current = setTimeout(() => {
            if (isActive && !isSpeaking && !isListening) startListeningRef.current?.();
          }, 1500);
        }
      };

      recognitionRef.current = recognition;
    }

    return () => {
      if (speechTimeoutRef.current) clearTimeout(speechTimeoutRef.current);
      if (recognitionRef.current) {
        try { recognitionRef.current.stop(); } catch (error) {}
      }
    };
  }, [userLanguage, isActive, isLanguageSet, isSpeaking]);

  useEffect(() => {
    if (!hasGreeted) {
      setTimeout(() => {
        initialGreeting();
        setHasGreeted(true);
      }, 1500);
    }
  }, []);

  const speak = useCallback((text: string, lang: string = userLanguage) => {
    if ('speechSynthesis' in window) {
      speechSynthesis.cancel();
      setIsSpeaking(true);

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang;
      utterance.rate = 0.85;
      utterance.pitch = 1.0;
      utterance.volume = 0.9;

      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => {
        setIsSpeaking(false);
        if (isLanguageSet && isActive) {
          setTimeout(() => {
            if (!isSpeaking && isActive) startListeningRef.current?.();
          }, 1000);
        }
      };
      utterance.onerror = () => setIsSpeaking(false);

      speechSynthesis.speak(utterance);
    }
  }, [userLanguage, isLanguageSet, isActive]);

  const initialGreeting = useCallback(() => {
    const greeting = `Welcome to Sense Vision AI, your accessible learning tool. I'm here to help you navigate and use this app with voice commands. Please tell me your preferred language. Say English, Hindi, or Telugu.`;
    speak(greeting, 'en-US');

    setTimeout(() => {
      if (!isSpeaking) startListeningRef.current?.();
    }, 3000);
  }, [speak]);

  const startListening = useCallback(() => {
    if (recognitionRef.current && isActive && !isStartingRef.current) {
      isStartingRef.current = true; // prevent multiple starts
      try {
        if (isListening) recognitionRef.current.stop();

        setTimeout(() => {
          if (recognitionRef.current && isActive) {
            recognitionRef.current.lang = userLanguage;
            recognitionRef.current.start();
          }
          isStartingRef.current = false; // reset after start
        }, 200);
      } catch (error) {
        console.error('Speech recognition start error:', error);
        setIsListening(false);
        isStartingRef.current = false;
      }
    }
  }, [isListening, isActive, userLanguage]);

  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      try { recognitionRef.current.stop(); } catch (error) {}
    }
    if (speechTimeoutRef.current) clearTimeout(speechTimeoutRef.current);
    setIsListening(false);
    isStartingRef.current = false; // ensure flag reset
  }, [isListening]);

  useEffect(() => { startListeningRef.current = startListening; }, [startListening]);

  const handleVoiceCommand = useCallback((command: string) => {
    if (!isLanguageSet) {
      if (command.includes('english')) { setUserLanguage('en-US'); setIsLanguageSet(true); speak('Language set to English. I will now help you navigate the app. You can say commands like upload document, read files, or explain image. What would you like to do?', 'en-US'); return; }
      else if (command.includes('hindi')) { setUserLanguage('hi-IN'); setIsLanguageSet(true); speak('भाषा हिंदी में सेट की गई। अब मैं आपको ऐप navigate करने में मदद करूँगा। आप document upload करें, files पढ़ें, या image explain करें कह सकते हैं। आप क्या करना चाहते हैं?', 'hi-IN'); return; }
      else if (command.includes('telugu')) { setUserLanguage('te-IN'); setIsLanguageSet(true); speak('భాష తెలుగులో సెట్ చేయబడింది। ఇప్పుడు నేను మీకు app navigate చేయడంలో సహాయం చేయగలను। మీరు document upload చేయండి, files చదవండి, లేదా image explain చేయండి అని చెప్పవచ్చు। మీరు ఏమి చేయాలనుకుంటున్నారు?', 'te-IN'); return; }
      else { speak('Please say English, Hindi, or Telugu to set your language preference.', 'en-US'); return; }
    }
    if (command.includes('home') || command.includes('main')) { onNavigate('home'); speak(getResponse('navigated_home')); }
    else if (command.includes('upload') || command.includes('add file') || command.includes('document')) { onNavigate('home'); speak(getResponse('upload_help')); }
    else if (command.includes('read') || command.includes('reader') || command.includes('text')) { onNavigate('reader'); speak(getResponse('navigated_reader')); }
    else if (command.includes('explain') || command.includes('explainer') || command.includes('image')) { onNavigate('explainer'); speak(getResponse('navigated_explainer')); }
    else if (command.includes('library') || command.includes('files')) { onNavigate('library'); speak(getResponse('navigated_library')); }
    else if (command.includes('help') || command.includes('what can you do')) { speak(getResponse('help')); }
    else if (command.includes('how many files') || command.includes('file count')) { speak(getResponse('file_count').replace('{count}', totalFiles.toString())); }
    else { speak(getResponse('not_understood')); }
  }, [onNavigate, speak, totalFiles, userLanguage, isLanguageSet]);

  const getResponse = (key: string) => {
    const responses = {
      'en-US': {
        navigated_home: `Navigated to home page. You can upload documents or images here. Say upload document for text files or upload image for visual content.`,
        navigated_reader: `Navigated to text reader. Select a document to read aloud. Say read document to start.`,
        navigated_explainer: `Navigated to AI explainer. Select an image for detailed explanation. Say explain image to analyze visual content.`,
        navigated_library: `Navigated to your library. Here are all your uploaded files. You have ${totalFiles} files.`,
        upload_help: `To upload files, say upload document for PDFs and text files, or say upload image for pictures and diagrams.`,
        help: `I can help you navigate the app using voice commands. Say home, reader, explainer, or library to navigate. Say upload document or upload image to add files. Say help anytime for assistance.`,
        file_count: `You have {count} files in your library.`,
        not_understood: `I didn't understand that command. Try saying home, reader, explainer, library, upload document, or help.`,
        not_clear: `I didn't hear that clearly. Please speak clearly and try again.`,
        no_speech: `I didn't hear anything. Please speak your command.`
      },
      'hi-IN': {
        navigated_home: `होम पेज पर गए। यहां आप documents या images upload कर सकते हैं। Document upload करने के लिए upload document कहें।`,
        navigated_reader: `Text reader पर गए। पढ़ने के लिए कोई document select करें। Read document कहकर शुरू करें।`,
        navigated_explainer: `AI explainer पर गए। विस्तृत explanation के लिए कोई image select करें। Explain image कहें।`,
        navigated_library: `आपकी library में गए। यहां आपकी सभी uploaded files हैं। आपके पास ${totalFiles} files हैं।`,
        upload_help: `Files upload करने के लिए, PDFs के लिए upload document कहें या images के लिए upload image कहें।`,
        help: `मैं voice commands से app navigate करने में मदद कर सकता हूं। Home, reader, explainer, या library कहें। Upload document या upload image कहें।`,
        file_count: `आपकी library में {count} files हैं।`,
        not_understood: `मैं समझ नहीं पाया। Home, reader, explainer, library, upload document, या help कहें।`,
        not_clear: `मैंने साफ नहीं सुना। कृपया साफ बोलें और फिर कोशिश करें।`,
        no_speech: `मैंने कुछ नहीं सुना। कृपया अपना command बोलें।`
      },
      'te-IN': {
        navigated_home: `Home page కి వెళ్ళాము। ఇక్కడ మీరు documents లేదా images upload చేయవచ్చు। Upload document అని చెప్పండి।`,
        navigated_reader: `Text reader కి వెళ్ళాము। చదవడానికి document select చేయండి। Read document అని చెప్పండి।`,
        navigated_explainer: `AI explainer కి వెళ్ళాము। వివరణ కోసం image select చేయండి। Explain image అని చెప్పండి।`,
        navigated_library: `మీ library కి వెళ్ళాము। ఇక్కడ మీ అన్ని files ఉన్నాయి। మీ దగ్గర ${totalFiles} files ఉన్నాయి।`,
        upload_help: `Files upload చేయడానికి, PDFs కోసం upload document అని చెప్పండి లేదా images కోసం upload image అని చెప్పండి।`,
        help: `నేను voice commands తో app navigate చేయడంలో సహాయం చేయగలను। Home, reader, explainer, లేదా library అని చెప్పండి।`,
        file_count: `మీ library లో {count} files ఉన్నాయి।`,
        not_understood: `నాకు అర్థం కాలేదు। Home, reader, explainer, library, upload document, లేదా help అని చెప్పండి।`,
        not_clear: `నేను స్పష్టంగా వినలేదు. దయచేసి స్పష్టంగా మాట్లాడు మరియు మళ్లీ ప్రయత్నించు।`,
        no_speech: `నేను ఏమీ వినలేదు. దయచేసి మీ command చెప్పండి।`
      }
    };
    return responses[userLanguage as keyof typeof responses]?.[key as keyof typeof responses['en-US']] || responses['en-US'][key as keyof typeof responses['en-US']];
  };

  const toggleAssistant = () => {
    if (isActive) {
      setIsActive(false);
      stopListening();
      speechSynthesis.cancel();
      setIsSpeaking(false);
      if (speechTimeoutRef.current) clearTimeout(speechTimeoutRef.current);
    } else {
      setIsActive(true);
      if (isLanguageSet) speak(getResponse('help'));
      else initialGreeting();
    }
  };

  return (
    <>
      {/* AI Assistant Button */}
      <div className="fixed bottom-24 right-4 z-50">
        <button
          onClick={toggleAssistant}
          className={`p-4 rounded-full shadow-clay-outer transition-all duration-300 ${
            isActive 
              ? 'bg-gradient-to-br from-green-200 to-green-300' 
              : 'bg-gradient-to-br from-red-200 to-red-300'
          }`}
          aria-label="AI Voice Assistant"
        >
          {!isActive ? (
            <VolumeX className="w-6 h-6 text-red-700" />
          ) : isSpeaking ? (
            <Volume2 className="w-6 h-6 text-green-700 animate-pulse" />
          ) : isListening ? (
            <Mic className="w-6 h-6 text-green-700 animate-pulse" />
          ) : (
            <MessageCircle className="w-6 h-6 text-green-700" />
          )}
        </button>
        {isActive && (
          <div className="absolute -top-2 -right-2 w-4 h-4 bg-green-500 rounded-full animate-ping"></div>
        )}
      </div>

      {/* Voice Assistant Panel */}
      {isActive && (
        <div className="fixed bottom-40 right-4 bg-white p-4 rounded-3xl shadow-clay-outer max-w-xs z-40">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-2">
              <MessageCircle className="w-5 h-5 text-blue-600" />
              <span className="font-bold text-gray-800">AI Assistant</span>
            </div>
            
            <div className="text-sm text-gray-600 mb-3">
              {!isLanguageSet ? 'Setting language...' :
               isSpeaking ? 'Speaking...' : 
               isListening ? 'Listening...' : 
               'Ready to help'}
            </div>
            
            {transcript && (
              <div className="text-xs text-gray-500 bg-gray-50 p-2 rounded-lg mb-2">
                "{transcript}"
              </div>
            )}
            
            <div className="text-xs text-gray-500">
              Language: {userLanguage === 'en-US' ? 'English' : 
                        userLanguage === 'hi-IN' ? 'Hindi' : 'Telugu'}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default AIVoiceAssistant;
