import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Mic, MicOff, Volume2, VolumeX, MessageCircle, Brain } from 'lucide-react';
import geminiService from '../services/geminiService';
import toast from 'react-hot-toast';

interface AIVoiceAssistantProps {
  onNavigate: (page: 'home' | 'reader' | 'explainer' | 'library') => void;
  onFileUpload: (files: File[], type: 'text' | 'visual') => void;
  totalFiles: number;
  currentPage: 'home' | 'reader' | 'explainer' | 'library';
  hasSelectedFile: boolean;
  isPlaying: boolean;
  onPlayAudio: () => void;
  onPauseAudio: () => void;
  onStopAudio: () => void;
  onResumeAudio: () => void;
  onSpeedUp: () => void;
  onSlowDown: () => void;
  onRepeatLast: () => void;
  onNextSection: () => void;
  onOpenSettings: () => void;
  onDownloadAudio?: () => void;
}

const AIVoiceAssistant: React.FC<AIVoiceAssistantProps> = ({ 
  onNavigate, 
  onFileUpload, 
  totalFiles,
  currentPage,
  hasSelectedFile,
  isPlaying,
  onPlayAudio,
  onPauseAudio,
  onStopAudio,
  onResumeAudio,
  onSpeedUp,
  onSlowDown,
  onRepeatLast,
  onNextSection,
  onOpenSettings,
  onDownloadAudio
}) => {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isActive, setIsActive] = useState(true);
  const [userLanguage, setUserLanguage] = useState('en-US');
  const [hasGreeted, setHasGreeted] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [isLanguageSet, setIsLanguageSet] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [lastResponse, setLastResponse] = useState('');
  
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const restartTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const isStartingRef = useRef(false);

  // Initialize continuous speech recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognition = new SpeechRecognition();

      recognition.continuous = true;
      recognition.interimResults = false;
      recognition.lang = userLanguage;
      recognition.maxAlternatives = 3;

      recognition.onstart = () => {
        setIsListening(true);
        setIsProcessing(false);
        isStartingRef.current = false;
      };

      recognition.onresult = async (event) => {
        const results = event.results;
        const lastResult = results[results.length - 1];
        
        if (lastResult.isFinal) {
          let bestTranscript = '';
          let bestConfidence = 0;
          
          for (let i = 0; i < lastResult.length; i++) {
            const result = lastResult[i];
            if (result.confidence > bestConfidence) {
              bestConfidence = result.confidence;
              bestTranscript = result.transcript;
            }
          }

          if (bestConfidence > 0.1) { // Very low threshold for accessibility
            setTranscript(bestTranscript);
            setIsProcessing(true);
            await handleVoiceCommand(bestTranscript.trim());
            setIsProcessing(false);
          }
        }
      };

      recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
        setIsProcessing(false);
        isStartingRef.current = false;

        if (event.error === 'no-speech') {
          if (isActive && isLanguageSet) {
            restartListening();
          }
        } else if (event.error === 'network') {
          speak('Network error. Retrying...');
          setTimeout(() => restartListening(), 2000);
        } else if (event.error === 'not-allowed') {
          speak('Please allow microphone access for voice commands.');
          toast.error('Microphone access required');
          setIsActive(false);
        } else {
          if (isActive && isLanguageSet) {
            setTimeout(() => restartListening(), 1000);
          }
        }
      };

      recognition.onend = () => {
        setIsListening(false);
        isStartingRef.current = false;
        
        if (isActive && isLanguageSet && !isSpeaking) {
          restartListening();
        }
      };

      recognitionRef.current = recognition;
    }

    return () => {
      if (restartTimeoutRef.current) clearTimeout(restartTimeoutRef.current);
      if (recognitionRef.current) {
        try { recognitionRef.current.stop(); } catch (error) {}
      }
    };
  }, [userLanguage, isActive, isLanguageSet, isSpeaking]);

  const restartListening = useCallback(() => {
    if (restartTimeoutRef.current) clearTimeout(restartTimeoutRef.current);
    
    restartTimeoutRef.current = setTimeout(() => {
      if (isActive && isLanguageSet && !isSpeaking && !isStartingRef.current) {
        startListening();
      }
    }, 500);
  }, [isActive, isLanguageSet, isSpeaking]);

  useEffect(() => {
    if (!hasGreeted) {
      setTimeout(() => {
        initialGreeting();
        setHasGreeted(true);
      }, 1000);
    }
  }, []);

  const speak = useCallback((text: string, lang: string = userLanguage) => {
    if ('speechSynthesis' in window) {
      speechSynthesis.cancel();
      setIsSpeaking(true);
      setLastResponse(text);

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang;
      utterance.rate = 0.9;
      utterance.pitch = 1.0;
      utterance.volume = 0.9;

      const voices = speechSynthesis.getVoices();
      const preferredVoice = voices.find(voice => 
        voice.lang.startsWith(lang.split('-')[0]) && voice.localService
      ) || voices.find(voice => voice.lang.startsWith(lang.split('-')[0]));
      
      if (preferredVoice) {
        utterance.voice = preferredVoice;
      }

      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => {
        setIsSpeaking(false);
        if (isActive && isLanguageSet) {
          setTimeout(() => {
            if (!isSpeaking && isActive) startListening();
          }, 500);
        }
      };
      utterance.onerror = () => setIsSpeaking(false);

      speechSynthesis.speak(utterance);
    }
  }, [userLanguage, isActive, isLanguageSet, isSpeaking]);

  const initialGreeting = useCallback(() => {
    const greeting = `Welcome to Sense Vision! I'm your AI assistant. I'm listening continuously for your commands. Please tell me your preferred language: say English, Hindi, or Telugu.`;
    speak(greeting, 'en-US');
  }, [speak]);

  const startListening = useCallback(() => {
    if (recognitionRef.current && isActive && !isStartingRef.current && !isSpeaking) {
      isStartingRef.current = true;
      try {
        if (isListening) {
          recognitionRef.current.stop();
        }

        setTimeout(() => {
          if (recognitionRef.current && isActive && !isSpeaking) {
            recognitionRef.current.lang = userLanguage;
            recognitionRef.current.start();
          }
        }, 300);
      } catch (error) {
        console.error('Speech recognition start error:', error);
        isStartingRef.current = false;
      }
    }
  }, [isListening, isActive, userLanguage, isSpeaking]);

  const handleVoiceCommand = useCallback(async (command: string) => {
    if (!isLanguageSet) {
      const lowerCommand = command.toLowerCase();
      if (lowerCommand.includes('english')) {
        setUserLanguage('en-US');
        setIsLanguageSet(true);
        speak('Perfect! Language set to English. I\'m ready to help you. I\'m listening continuously. You can say "go to reader", "upload document", "explain image", or "help" for commands.', 'en-US');
        return;
      } else if (lowerCommand.includes('hindi')) {
        setUserLanguage('hi-IN');
        setIsLanguageSet(true);
        speak('बहुत बढ़िया! भाषा हिंदी में सेट की गई। मैं आपकी मदद के लिए तैयार हूं। मैं लगातार सुन रहा हूं। आप "रीडर पर जाएं", "डॉक्यूमेंट अपलोड करें" कह सकते हैं।', 'hi-IN');
        return;
      } else if (lowerCommand.includes('telugu')) {
        setUserLanguage('te-IN');
        setIsLanguageSet(true);
        speak('అద్భుతం! భాష తెలుగులో సెట్ చేయబడింది. నేను మీకు సహాయం చేయడానికి సిద్ధంగా ఉన్నాను. నేను నిరంతరం వింటున్నాను. మీరు "రీడర్‌కు వెళ్లండి", "డాక్యుమెంట్ అప్‌లోడ్ చేయండి" అని చెప్పవచ్చు.', 'te-IN');
        return;
      } else {
        speak('Please clearly say "English", "Hindi", or "Telugu" to set your language.', 'en-US');
        return;
      }
    }

    try {
      const context = {
        currentPage,
        totalFiles,
        hasSelectedFile,
        isPlaying,
        userLanguage
      };

      const result = await geminiService.processVoiceCommand(command, context);
      
      switch (result.action) {
        case 'navigate_home':
          onNavigate('home');
          break;
        case 'navigate_reader':
          onNavigate('reader');
          break;
        case 'navigate_explainer':
          onNavigate('explainer');
          break;
        case 'navigate_library':
          onNavigate('library');
          break;
        case 'upload_document':
          onNavigate('home');
          toast.success('Ready to upload documents!');
          break;
        case 'upload_image':
          onNavigate('home');
          toast.success('Ready to upload images!');
          break;
        case 'play_audio':
          onPlayAudio();
          break;
        case 'pause_audio':
          onPauseAudio();
          break;
        case 'stop_audio':
          onStopAudio();
          break;
        case 'resume_audio':
          onResumeAudio();
          break;
        case 'speed_up':
          onSpeedUp();
          break;
        case 'slow_down':
          onSlowDown();
          break;
        case 'repeat_last':
          onRepeatLast();
          break;
        case 'next_section':
          onNextSection();
          break;
        case 'settings':
          onOpenSettings();
          break;
        case 'download_audio':
          if (onDownloadAudio) {
            onDownloadAudio();
          }
          break;
        case 'help':
          const helpText = getHelpText();
          speak(helpText);
          return;
        case 'file_count':
          break;
        default:
          break;
      }

      speak(result.response);
      
    } catch (error) {
      console.error('Error processing voice command:', error);
      speak('I encountered an error. Please try again.');
    }
  }, [onNavigate, speak, totalFiles, userLanguage, isLanguageSet, currentPage, hasSelectedFile, isPlaying, onPlayAudio, onPauseAudio, onStopAudio, onResumeAudio, onSpeedUp, onSlowDown, onRepeatLast, onNextSection, onOpenSettings, onDownloadAudio]);

  const getHelpText = () => {
    const helpCommands = {
      'en-US': `I can help you with many commands! Navigation: "Go home", "Open reader", "Show library". Audio: "Play", "Pause", "Speed up". Content: "Explain image", "Download audio". I'm listening continuously!`,
      'hi-IN': `मैं कई कमांड्स में मदद कर सकता हूं! नेवीगेशन: "होम जाएं", "रीडर खोलें"। ऑडियो: "प्ले करें", "पॉज़ करें"। मैं लगातार सुन रहा हूं!`,
      'te-IN': `నేను అనేక కమాండ్లతో సహాయం చేయగలను! నావిగేషన్: "హోమ్‌కు వెళ్లండి", "రీడర్ తెరవండి"। ఆడియో: "ప్లే చేయండి", "పాజ్ చేయండి"। నేను నిరంతరం వింటున్నాను!`
    };
    
    return helpCommands[userLanguage as keyof typeof helpCommands] || helpCommands['en-US'];
  };

  const toggleAssistant = () => {
    if (isActive) {
      setIsActive(false);
      if (recognitionRef.current) {
        try { recognitionRef.current.stop(); } catch (error) {}
      }
      speechSynthesis.cancel();
      setIsSpeaking(false);
      toast.success('Voice assistant deactivated');
    } else {
      setIsActive(true);
      if (isLanguageSet) {
        speak('Voice assistant activated! I\'m listening continuously.');
        setTimeout(() => startListening(), 1000);
      } else {
        initialGreeting();
      }
      toast.success('Voice assistant activated');
    }
  };

  return (
    <>
      <div className="fixed bottom-24 right-4 z-50">
        <button
          onClick={toggleAssistant}
          className={`p-4 rounded-full shadow-clay-outer transition-all duration-300 ${
            isActive 
              ? 'bg-gradient-to-br from-green-200 to-green-300' 
              : 'bg-gradient-to-br from-red-200 to-red-300'
          }`}
          aria-label="AI Voice Assistant"
        >
          {!isActive ? (
            <VolumeX className="w-6 h-6 text-red-700" />
          ) : isSpeaking ? (
            <Volume2 className="w-6 h-6 text-green-700 animate-pulse" />
          ) : isListening ? (
            <Mic className="w-6 h-6 text-green-700 animate-pulse" />
          ) : isProcessing ? (
            <Brain className="w-6 h-6 text-blue-700 animate-spin" />
          ) : (
            <MessageCircle className="w-6 h-6 text-green-700" />
          )}
        </button>
        {isActive && (
          <div className="absolute -top-2 -right-2 w-4 h-4 bg-green-500 rounded-full animate-ping"></div>
        )}
      </div>

      {isActive && (
        <div className="fixed bottom-40 right-4 bg-white p-4 rounded-3xl shadow-clay-outer max-w-xs z-40">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-2">
              <Brain className="w-5 h-5 text-blue-600" />
              <span className="font-bold text-gray-800">AI Assistant</span>
            </div>
            
            <div className="text-sm text-gray-600 mb-3">
              {!isLanguageSet ? 'Setting language...' :
               isProcessing ? 'Processing...' :
               isSpeaking ? 'Speaking...' : 
               isListening ? 'Listening...' : 
               'Ready'}
            </div>
            
            {transcript && (
              <div className="text-xs text-gray-500 bg-gray-50 p-2 rounded-lg mb-2">
                "{transcript}"
              </div>
            )}
            
            <div className="text-xs text-gray-500">
              {userLanguage === 'en-US' ? 'English' : 
               userLanguage === 'hi-IN' ? 'Hindi' : 'Telugu'}
            </div>
            
            <div className="text-xs text-green-600 mt-1">
              Powered by Gemini AI
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default AIVoiceAssistant;