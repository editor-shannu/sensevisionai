import React from 'react';
import { Mic, MicOff, Volume2, VolumeX, SkipForward, RotateCcw, Settings } from 'lucide-react';
import { TTSSettings } from '../types';
import { SUPPORTED_LANGUAGES } from '../config/constants';

interface VoiceControlsProps {
  isListening: boolean;
  onStartListening: () => void;
  onStopListening: () => void;
  isPlaying: boolean;
  onPlay: () => void;
  onPause: () => void;
  onNext: () => void;
  onRepeat: () => void;
  settings: TTSSettings;
  onSettingsChange: (settings: TTSSettings) => void;
}

const VoiceControls: React.FC<VoiceControlsProps> = ({
  isListening,
  onStartListening,
  onStopListening,
  isPlaying,
  onPlay,
  onPause,
  onNext,
  onRepeat,
  settings,
  onSettingsChange
}) => {
  const [showSettings, setShowSettings] = React.useState(false);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap justify-center gap-4">
        {/* Voice Command Button */}
        <button
          onClick={isListening ? onStopListening : onStartListening}
          className={`flex items-center space-x-3 px-8 py-4 rounded-3xl font-medium text-lg shadow-clay-soft hover:shadow-clay-inset transition-all duration-300 ${
            isListening
              ? 'bg-gradient-to-r from-red-200 to-red-300 text-red-700 animate-pulse'
              : 'bg-gradient-to-r from-blue-200 to-blue-300 text-blue-700 hover:from-blue-300 hover:to-blue-400'
          }`}
          aria-label={isListening ? 'Stop listening' : 'Start voice commands'}
        >
          {isListening ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
          <span>{isListening ? 'Listening...' : 'Voice Commands'}</span>
        </button>

        {/* Play/Pause Button */}
        <button
          onClick={isPlaying ? onPause : onPlay}
          className="flex items-center space-x-3 px-8 py-4 rounded-3xl font-medium text-lg bg-gradient-to-r from-purple-200 to-purple-300 text-purple-700 hover:from-purple-300 hover:to-purple-400 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300"
          aria-label={isPlaying ? 'Pause reading' : 'Start reading'}
        >
          {isPlaying ? <VolumeX className="w-6 h-6" /> : <Volume2 className="w-6 h-6" />}
          <span>{isPlaying ? 'Pause' : 'Read Aloud'}</span>
        </button>
      </div>

      <div className="flex justify-center space-x-4">
        <button
          onClick={onNext}
          className="flex items-center space-x-2 px-6 py-3 rounded-2xl bg-gradient-to-r from-green-200 to-green-300 text-green-700 hover:from-green-300 hover:to-green-400 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300"
          aria-label="Next section"
        >
          <SkipForward className="w-5 h-5" />
          <span>Next</span>
        </button>

        <button
          onClick={onRepeat}
          className="flex items-center space-x-2 px-6 py-3 rounded-2xl bg-gradient-to-r from-yellow-200 to-yellow-300 text-yellow-700 hover:from-yellow-300 hover:to-yellow-400 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300"
          aria-label="Repeat last sentence"
        >
          <RotateCcw className="w-5 h-5" />
          <span>Repeat</span>
        </button>

        <button
          onClick={() => setShowSettings(!showSettings)}
          className="flex items-center space-x-2 px-6 py-3 rounded-2xl bg-gradient-to-r from-gray-200 to-gray-300 text-gray-700 hover:from-gray-300 hover:to-gray-400 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300"
          aria-label="Settings"
        >
          <Settings className="w-5 h-5" />
          <span>Settings</span>
        </button>
      </div>

      {/* Settings Panel */}
      {showSettings && (
        <div className="p-6 rounded-3xl bg-gradient-to-br from-gray-50 to-white border-2 border-gray-100 shadow-clay-inset">
          <h3 className="text-xl font-bold text-gray-800 mb-4">Voice Settings</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Language
              </label>
              <select
                value={settings.language}
                onChange={(e) => onSettingsChange({
                  ...settings,
                  language: e.target.value,
                  voice: SUPPORTED_LANGUAGES.find(l => l.code === e.target.value)?.voice || settings.voice
                })}
                className="w-full px-4 py-3 rounded-2xl border-2 border-gray-200 bg-white shadow-clay-soft focus:shadow-clay-inset focus:border-purple-300 outline-none transition-all duration-200"
              >
                {SUPPORTED_LANGUAGES.map((lang) => (
                  <option key={lang.code} value={lang.code}>
                    {lang.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Reading Style
              </label>
              <select
                value={settings.emotion}
                onChange={(e) => onSettingsChange({
                  ...settings,
                  emotion: e.target.value as TTSSettings['emotion']
                })}
                className="w-full px-4 py-3 rounded-2xl border-2 border-gray-200 bg-white shadow-clay-soft focus:shadow-clay-inset focus:border-purple-300 outline-none transition-all duration-200"
              >
                <option value="academic">Academic (Clear & Formal)</option>
                <option value="instruction">Instruction (Calm & Steady)</option>
                <option value="storytelling">Storytelling (Expressive & Lively)</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Speed: {settings.speed.toFixed(1)}x
              </label>
              <input
                type="range"
                min="0.5"
                max="2.0"
                step="0.1"
                value={settings.speed}
                onChange={(e) => onSettingsChange({
                  ...settings,
                  speed: parseFloat(e.target.value)
                })}
                className="w-full"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Pitch: {settings.pitch > 0 ? '+' : ''}{settings.pitch}
              </label>
              <input
                type="range"
                min="-10"
                max="10"
                step="1"
                value={settings.pitch}
                onChange={(e) => onSettingsChange({
                  ...settings,
                  pitch: parseInt(e.target.value)
                })}
                className="w-full"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VoiceControls;