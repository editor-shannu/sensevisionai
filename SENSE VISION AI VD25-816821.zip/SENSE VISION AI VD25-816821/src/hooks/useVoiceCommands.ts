import { useState, useEffect, useCallback } from 'react';
import { VOICE_COMMANDS } from '../config/constants';
import googleCloudService from '../services/googleCloudService';

export const useVoiceCommands = (onCommand: (action: string) => void) => {
  const [isListening, setIsListening] = useState(false);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [recognition, setRecognition] = useState<SpeechRecognition | null>(null);

  useEffect(() => {
    // Try to use native Web Speech API first (faster)
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognitionInstance = new SpeechRecognition();
      
      recognitionInstance.continuous = false;
      recognitionInstance.interimResults = false;
      recognitionInstance.lang = 'en-US';
      
      recognitionInstance.onresult = (event) => {
        const transcript = event.results[0][0].transcript.toLowerCase();
        handleVoiceCommand(transcript);
      };
      
      recognitionInstance.onend = () => {
        setIsListening(false);
      };
      
      setRecognition(recognitionInstance);
    }
  }, []);

  const handleVoiceCommand = useCallback((transcript: string) => {
    const command = VOICE_COMMANDS.find(cmd => 
      transcript.includes(cmd.command.toLowerCase())
    );
    
    if (command) {
      onCommand(command.action);
    }
  }, [onCommand]);

  const startListening = useCallback(async () => {
    try {
      setIsListening(true);
      
      if (recognition) {
        // Use native speech recognition
        recognition.start();
      } else {
        // Fallback message
        console.log('Speech recognition not supported in this browser');
        setIsListening(false);
      }
    } catch (error) {
      console.error('Voice command error:', error);
      setIsListening(false);
    }
  }, [recognition, handleVoiceCommand]);

  const stopListening = useCallback(() => {
    if (recognition) {
      recognition.stop();
    }
    if (mediaRecorder && mediaRecorder.state === 'recording') {
      mediaRecorder.stop();
    }
    setIsListening(false);
  }, [recognition, mediaRecorder]);

  return {
    isListening,
    startListening,
    stopListening
  };
};