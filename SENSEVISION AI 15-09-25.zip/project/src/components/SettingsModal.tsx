import React, { useState, useEffect } from 'react';
import { X, Volume2, Eye, Type, Globe } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Settings {
  language: string;
  voice: string;
  narrationStyle: string;
  readingSpeed: number;
  volume: number;
  highContrast: boolean;
  largeText: boolean;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  const [settings, setSettings] = useState<Settings>({
    language: 'en-US',
    voice: 'default',
    narrationStyle: 'academic',
    readingSpeed: 1,
    volume: 80,
    highContrast: false,
    largeText: false
  });

  const [testingVoice, setTestingVoice] = useState(false);

  // Load settings from localStorage on mount
  useEffect(() => {
    const savedSettings = localStorage.getItem('senseVisionSettings');
    if (savedSettings) {
      try {
        const parsed = JSON.parse(savedSettings);
        setSettings(parsed);
        // Apply settings to document
        applySettings(parsed);
      } catch (error) {
        console.error('Error loading settings:', error);
      }
    }
  }, []);

  const applySettings = (newSettings: Settings) => {
    const body = document.body;
    
    // Apply high contrast
    if (newSettings.highContrast) {
      body.classList.add('high-contrast');
    } else {
      body.classList.remove('high-contrast');
    }

    // Apply large text
    if (newSettings.largeText) {
      body.classList.add('large-text');
    } else {
      body.classList.remove('large-text');
    }
  };

  const handleSettingChange = (key: keyof Settings, value: any) => {
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);
    
    // Save to localStorage
    localStorage.setItem('senseVisionSettings', JSON.stringify(newSettings));
    
    // Apply settings immediately
    applySettings(newSettings);
  };

  const testVoiceSettings = async () => {
    if (testingVoice) return;
    
    setTestingVoice(true);
    
    try {
      if ('speechSynthesis' in window) {
        speechSynthesis.cancel();
        
        const utterance = new SpeechSynthesisUtterance(
          'This is a test of your voice settings. The quick brown fox jumps over the lazy dog.'
        );
        
        utterance.lang = settings.language;
        utterance.rate = settings.readingSpeed;
        utterance.volume = settings.volume / 100;
        
        // Apply narration style
        switch (settings.narrationStyle) {
          case 'storytelling':
            utterance.pitch = 1.2;
            break;
          case 'instruction':
            utterance.pitch = 1.0;
            break;
          case 'academic':
            utterance.pitch = 0.9;
            break;
        }
        
        utterance.onend = () => setTestingVoice(false);
        utterance.onerror = () => setTestingVoice(false);
        
        speechSynthesis.speak(utterance);
      }
    } catch (error) {
      console.error('Voice test error:', error);
      setTestingVoice(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl shadow-clay-outer max-w-md w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-800">Settings</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-2xl bg-gradient-to-br from-gray-200 to-gray-300 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300"
          >
            <X className="w-6 h-6 text-gray-600" />
          </button>
        </div>

        <div className="p-6 space-y-8">
          {/* Language & Voice */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Globe className="w-5 h-5 text-purple-600" />
              <h3 className="text-lg font-bold text-gray-800">Language & Voice</h3>
            </div>
            <p className="text-gray-600 text-sm mb-4">Choose your preferred language and voice settings</p>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Primary Language
                </label>
                <select
                  value={settings.language}
                  onChange={(e) => handleSettingChange('language', e.target.value)}
                  className="w-full px-4 py-3 rounded-2xl border-2 border-gray-200 bg-white shadow-clay-soft focus:shadow-clay-inset focus:border-purple-300 outline-none transition-all duration-200 mobile-text"
                >
                  <option value="en-US">English</option>
                  <option value="hi-IN">Hindi</option>
                  <option value="te-IN">Telugu</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Narration Style
                </label>
                <select
                  value={settings.narrationStyle}
                  onChange={(e) => handleSettingChange('narrationStyle', e.target.value)}
                  className="w-full px-4 py-3 rounded-2xl border-2 border-gray-200 bg-white shadow-clay-soft focus:shadow-clay-inset focus:border-purple-300 outline-none transition-all duration-200 mobile-text"
                >
                  <option value="academic">📚 Academic (Clear & Formal)</option>
                  <option value="instruction">🎯 Instruction (Calm & Steady)</option>
                  <option value="storytelling">📖 Storytelling (Expressive & Lively)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Audio Controls */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Volume2 className="w-5 h-5 text-purple-600" />
              <h3 className="text-lg font-bold text-gray-800">Audio Controls</h3>
            </div>
            <p className="text-gray-600 text-sm mb-4">Adjust playback speed and volume</p>
            
            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-medium text-gray-700">Reading Speed</label>
                  <span className="text-sm text-gray-600">{settings.readingSpeed}x</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-xs text-gray-500">Slow</span>
                  <input
                    type="range"
                    min="0.5"
                    max="2.0"
                    step="0.1"
                    value={settings.readingSpeed}
                    onChange={(e) => handleSettingChange('readingSpeed', parseFloat(e.target.value))}
                    className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                  />
                  <span className="text-xs text-gray-500">Fast</span>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-medium text-gray-700">Volume</label>
                  <span className="text-sm text-gray-600">{settings.volume}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={settings.volume}
                  onChange={(e) => handleSettingChange('volume', parseInt(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                />
              </div>

              <button
                onClick={testVoiceSettings}
                disabled={testingVoice}
                className="w-full px-4 py-3 rounded-2xl border-2 border-gray-200 bg-white shadow-clay-soft focus:shadow-clay-inset focus:border-purple-300 outline-none transition-all duration-200 mobile-text text-gray-800 font-medium"
              >
                <Volume2 className="w-5 h-5 text-purple-700" />
                <span className="font-medium text-purple-700">
                  {testingVoice ? 'Testing...' : '🎵 Test Voice Settings'}
                </span>
              </button>
            </div>
          </div>

          {/* Accessibility */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Eye className="w-5 h-5 text-purple-600" />
              <h3 className="text-lg font-bold text-gray-800">Accessibility</h3>
            </div>
            <p className="text-gray-600 text-sm mb-4">Visual and interaction preferences</p>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 rounded-2xl bg-gray-50 shadow-clay-inset">
                <div>
                  <h4 className="font-medium text-gray-800">High Contrast Mode</h4>
                  <p className="text-sm text-gray-600">Increases visual contrast for better readability</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.highContrast}
                    onChange={(e) => handleSettingChange('highContrast', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                </label>
              </div>

              <div className="flex items-center justify-between p-4 rounded-2xl bg-gray-50 shadow-clay-inset">
                <div>
                  <h4 className="font-medium text-gray-800">Large Text</h4>
                  <p className="text-sm text-gray-600">Increases font size throughout the app</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.largeText}
                    onChange={(e) => handleSettingChange('largeText', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;