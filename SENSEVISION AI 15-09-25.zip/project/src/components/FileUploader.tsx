import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, FileText, Image } from 'lucide-react';

interface FileUploaderProps {
  onFileUpload: (files: File[]) => void;
  isProcessing: boolean;
}

const FileUploader: React.FC<FileUploaderProps> = ({ onFileUpload, isProcessing }) => {
  const onDrop = useCallback((acceptedFiles: File[]) => {
    onFileUpload(acceptedFiles);
  }, [onFileUpload]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'text/plain': ['.txt'],
      'image/*': ['.jpg', '.jpeg', '.png', '.bmp', '.gif']
    },
    disabled: isProcessing
  });

  return (
    <div
      {...getRootProps()}
      className={`relative border-3 border-dashed rounded-3xl p-12 text-center cursor-pointer transition-all duration-300 shadow-clay-soft ${
        isDragActive
          ? 'border-purple-300 bg-purple-50 shadow-clay-inset'
          : 'border-gray-200 bg-white shadow-clay-outer hover:shadow-clay-hover'
      } ${isProcessing ? 'opacity-50 cursor-not-allowed' : ''}`}
      style={{
        background: isDragActive 
          ? 'linear-gradient(145deg, #f3e8ff, #e9d5ff)' 
          : 'linear-gradient(145deg, #ffffff, #f8fafc)'
      }}
    >
      <input {...getInputProps()} aria-label="Upload study materials" />
      
      <div className="space-y-6">
        <div className="flex justify-center space-x-4">
          <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-100 to-purple-200 shadow-clay-soft">
            <Upload className="w-8 h-8 text-purple-600" />
          </div>
          <div className="p-4 rounded-2xl bg-gradient-to-br from-green-100 to-green-200 shadow-clay-soft">
            <FileText className="w-8 h-8 text-green-600" />
          </div>
          <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-100 to-blue-200 shadow-clay-soft">
            <Image className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        
        <div>
          <h3 className="text-2xl font-bold text-gray-800 mb-2">
            {isDragActive ? 'Drop your files here!' : 'Upload Study Materials'}
          </h3>
          <p className="text-gray-600 text-lg">
            Drag & drop or click to upload PDFs, images, documents
          </p>
          <p className="text-sm text-gray-500 mt-2">
            Supports: PDF, DOCX, TXT, JPG, PNG (Max 10MB each)
          </p>
        </div>
        
        {isProcessing && (
          <div className="inline-flex items-center px-6 py-3 rounded-2xl bg-gradient-to-r from-yellow-100 to-yellow-200 shadow-clay-inset">
            <div className="animate-spin rounded-full h-5 w-5 border-2 border-yellow-600 border-t-transparent mr-3"></div>
            <span className="text-yellow-700 font-medium">Processing files...</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default FileUploader;