import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { FileText, Image, Upload } from 'lucide-react';

interface HomePageProps {
  onFileUpload: (files: File[], type: 'text' | 'visual') => void;
  isProcessing: boolean;
  onNavigate: (page: 'home' | 'reader' | 'explainer' | 'library') => void;
  totalFiles: number;
}

const HomePage: React.FC<HomePageProps> = ({ onFileUpload, isProcessing, onNavigate, totalFiles }) => {
  const onDropText = useCallback((acceptedFiles: File[]) => {
    onFileUpload(acceptedFiles, 'text');
  }, [onFileUpload]);

  const onDropVisual = useCallback((acceptedFiles: File[]) => {
    onFileUpload(acceptedFiles, 'visual');
  }, [onFileUpload]);

  const { getRootProps: getTextRootProps, getInputProps: getTextInputProps, isDragActive: isTextDragActive } = useDropzone({
    onDrop: onDropText,
    accept: {
      'application/pdf': ['.pdf'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'application/vnd.ms-powerpoint': ['.ppt'],
      'application/vnd.openxmlformats-officedocument.presentationml.presentation': ['.pptx'],
      'text/plain': ['.txt']
    },
    disabled: isProcessing
  });

  const { getRootProps: getVisualRootProps, getInputProps: getVisualInputProps, isDragActive: isVisualDragActive } = useDropzone({
    onDrop: onDropVisual,
    accept: {
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
      'image/gif': ['.gif'],
      'image/bmp': ['.bmp']
    },
    disabled: isProcessing
  });

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-4 sm:py-8">
      {/* Welcome Section */}
      <div className="text-center mb-8 sm:mb-12">
        <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-4">
          Welcome to Your Learning Companion
        </h2>
        <p className="text-base sm:text-lg text-gray-600 max-w-2xl mx-auto px-4">
          Upload your study materials and let AI help you learn through accessible audio explanations
        </p>
      </div>

      {/* Upload Sections */}
      <div className="grid sm:grid-cols-2 gap-6 sm:gap-8 mb-8 sm:mb-12">
        {/* Text Documents */}
        <div
          {...getTextRootProps()}
          className={`relative p-6 sm:p-8 rounded-3xl border-3 border-dashed cursor-pointer transition-all duration-300 mobile-touch-target ${
            isTextDragActive
              ? 'border-purple-400 bg-purple-50 shadow-clay-inset'
              : 'border-gray-300 bg-white shadow-clay-soft hover:shadow-clay-hover'
          } ${isProcessing ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          <input {...getTextInputProps()} />
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-12 h-12 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-br from-purple-200 to-purple-300 shadow-clay-soft mb-4">
              <FileText className="w-6 h-6 sm:w-8 sm:h-8 text-purple-700" />
            </div>
            <h3 className="text-lg sm:text-xl font-bold text-gray-800 mb-2">Text Documents</h3>
            <p className="text-sm sm:text-base text-gray-600 mb-4">
              Upload documents or photos of text to be read aloud.
            </p>
            <div className="text-sm text-gray-500">
              <p>Supported: PDF, TXT, PPT, DOCX</p>
              <p>Max size: 10MB</p>
            </div>
          </div>
        </div>

        {/* Visual Content */}
        <div
          {...getVisualRootProps()}
          className={`relative p-6 sm:p-8 rounded-3xl border-3 border-dashed cursor-pointer transition-all duration-300 mobile-touch-target ${
            isVisualDragActive
              ? 'border-purple-400 bg-purple-50 shadow-clay-inset'
              : 'border-gray-300 bg-white shadow-clay-soft hover:shadow-clay-hover'
          } ${isProcessing ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          <input {...getVisualInputProps()} />
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-12 h-12 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-br from-purple-200 to-purple-300 shadow-clay-soft mb-4">
              <Image className="w-6 h-6 sm:w-8 sm:h-8 text-purple-700" />
            </div>
            <h3 className="text-lg sm:text-xl font-bold text-gray-800 mb-2">Visual Content</h3>
            <p className="text-sm sm:text-base text-gray-600 mb-4">
              Upload diagrams, graphs, or charts for an AI-powered explanation.
            </p>
            <div className="text-sm text-gray-500">
              <p>Supported: PNG, JPG, GIF, BMP</p>
              <p>Max size: 10MB</p>
            </div>
          </div>
        </div>
      </div>

      {/* Accessibility Features */}
      <div>
        <h3 className="text-lg sm:text-xl font-bold text-gray-800 mb-4 sm:mb-6">Accessibility Features</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
          <div className="text-center p-4 sm:p-6 rounded-3xl bg-white shadow-clay-soft">
            <div className="inline-flex items-center justify-center w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-br from-blue-200 to-blue-300 shadow-clay-soft mb-4">
              <span className="text-blue-700 font-bold">TTS</span>
            </div>
            <h4 className="text-sm sm:text-base font-bold text-gray-800 mb-2">Text-to-Speech</h4>
            <p className="text-sm text-gray-600">Natural voice reading</p>
          </div>
          
          <div className="text-center p-4 sm:p-6 rounded-3xl bg-white shadow-clay-soft">
            <div className="inline-flex items-center justify-center w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-br from-green-200 to-green-300 shadow-clay-soft mb-4">
              <span className="text-green-700 font-bold">AI</span>
            </div>
            <h4 className="text-sm sm:text-base font-bold text-gray-800 mb-2">AI Explanations</h4>
            <p className="text-sm text-gray-600">Smart content analysis</p>
          </div>
          
          <div className="text-center p-4 sm:p-6 rounded-3xl bg-white shadow-clay-soft">
            <div className="inline-flex items-center justify-center w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-br from-purple-200 to-purple-300 shadow-clay-soft mb-4">
              <span className="text-purple-700 font-bold">ML</span>
            </div>
            <h4 className="text-sm sm:text-base font-bold text-gray-800 mb-2">Multi-language</h4>
            <p className="text-sm text-gray-600">English, Hindi, Telugu</p>
          </div>
        </div>
      </div>

      {/* Processing Indicator */}
      {isProcessing && (
        <div className="fixed inset-0 bg-black/20 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white p-6 sm:p-8 rounded-3xl shadow-clay-soft max-w-sm w-full">
            <div className="flex items-center space-x-4">
              <div className="animate-spin rounded-full h-8 w-8 border-4 border-purple-300 border-t-purple-600"></div>
              <span className="text-base sm:text-lg font-medium text-gray-800">Processing files...</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default HomePage;