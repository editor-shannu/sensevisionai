import { StudyFile, APIResponse } from '../types';
import mammoth from 'mammoth';
import { getDocument } from 'pdfjs-dist';
import Tesseract from 'tesseract.js';

class FileProcessingService {
  async processFile(file: File): Promise<APIResponse> {
    try {
      console.log(`Processing ${file.name}...`);
      
      const studyFile: StudyFile = {
        id: crypto.randomUUID(),
        name: file.name,
        type: file.type,
        size: file.size,
        uploadedAt: new Date(),
        status: 'processing',
        contentType: this.determineContentType(file)
      };

      let content = '';
      
      // Process files based on type with optimized methods
      switch (file.type) {
        case 'application/pdf':
          content = await this.extractPDFText(file);
          break;
        case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
          content = await this.extractDocxText(file);
          break;
        case 'text/plain':
          content = await this.extractPlainText(file);
          break;
        case 'application/vnd.ms-powerpoint':
        case 'application/vnd.openxmlformats-officedocument.presentationml.presentation':
          content = await this.extractPresentationText(file);
          break;
        default:
          if (file.type.startsWith('image/')) {
            content = await this.extractImageText(file);
          } else {
            throw new Error('Unsupported file type');
          }
      }

      studyFile.content = content;
      studyFile.status = 'ready';
      
      return { success: true, data: studyFile };
    } catch (error) {
      return { success: false, error: `File processing failed: ${error}` };
    }
  }

  private determineContentType(file: File): 'text' | 'visual' {
    // Check file type
    if (file.type.startsWith('image/')) {
      return 'visual';
    }
    
    // Text document types
    const textTypes = [
      'application/pdf',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-powerpoint',
      'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      'text/plain'
    ];
    
    if (textTypes.includes(file.type)) {
      return 'text';
    }
    
    // Default to text for unknown types
    return 'text';
  }

  private async extractPDFText(file: File): Promise<string> {
    try {
      const arrayBuffer = await file.arrayBuffer();
      
      // Configure PDF.js for better performance
      const loadingTask = getDocument({ 
        data: arrayBuffer,
        useWorkerFetch: false,
        isEvalSupported: false,
        useSystemFonts: true
      });
      
      const pdf = await getDocument({ data: arrayBuffer }).promise;
      let text = '';
      const maxPages = Math.min(pdf.numPages, 50); // Limit to 50 pages for performance
      
      for (let i = 1; i <= maxPages; i++) {
        const page = await pdf.getPage(i);
        const textContent = await page.getTextContent();
        const pageText = textContent.items
          .map((item: any) => item.str)
          .join(' ');
        text += pageText + '\n';
        
        // Add progress feedback for large files
        if (i % 10 === 0) {
          console.log(`Processed ${i}/${maxPages} pages`);
        }
      }
      
      if (pdf.numPages > 50) {
        text += `\n\n[Note: This document has ${pdf.numPages} pages. Only the first 50 pages were processed for performance reasons.]`;
      }
      
      return text.trim();
    } catch (error) {
      throw new Error(`PDF processing failed: ${error}`);
    }
  }

  private async extractDocxText(file: File): Promise<string> {
    try {
      const arrayBuffer = await file.arrayBuffer();
      
      // Use mammoth with better options for large files
      const result = await mammoth.extractRawText({ 
        arrayBuffer,
        options: {
          includeDefaultStyleMap: false,
          includeEmbeddedStyleMap: false
        }
      });
      
      return result.value;
    } catch (error) {
      throw new Error(`DOCX processing failed: ${error}`);
    }
  }

  private async extractPresentationText(file: File): Promise<string> {
    try {
      // For PPT files, we'll extract what we can
      const text = await file.text();
      return text || `PowerPoint presentation: ${file.name}. This file contains slides that may include text, images, and other content. For best results, please convert to PDF or upload individual slide images.`;
    } catch (error) {
      return `PowerPoint presentation: ${file.name}. Unable to extract text content. Please convert to PDF format for better text extraction.`;
    }
  }

  private async extractPlainText(file: File): Promise<string> {
    try {
      const text = await file.text();
      
      // Handle very large text files
      if (text.length > 100000) { // 100KB limit
        const truncated = text.substring(0, 100000);
        return truncated + '\n\n[Note: This is a large text file. Only the first 100,000 characters were processed for performance reasons.]';
      }
      
      return text;
    } catch (error) {
      throw new Error(`Text file processing failed: ${error}`);
    }
  }

  private async extractImageText(file: File): Promise<string> {
    try {
      // Optimize image before OCR for better performance
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();
      
      return new Promise((resolve, reject) => {
        img.onload = async () => {
          // Resize image if too large (max 1200px width)
          const maxWidth = 1200;
          const scale = Math.min(1, maxWidth / img.width);
          
          canvas.width = img.width * scale;
          canvas.height = img.height * scale;
          
          ctx?.drawImage(img, 0, 0, canvas.width, canvas.height);
          
          // Convert to blob for OCR
          canvas.toBlob(async (blob) => {
            if (!blob) {
              reject(new Error('Failed to process image'));
              return;
            }
            
            try {
              // Use optimized Tesseract settings
      const result = await Tesseract.recognize(file, 'eng', {
                logger: () => {}, // Disable logging
                tessedit_pageseg_mode: Tesseract.PSM.AUTO,
                tessedit_char_whitelist: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 .,!?-:;()[]{}"\'/\\@#$%^&*+=<>|`~'
      });
      
      const extractedText = result.data.text.trim();
      
      if (!extractedText) {
                resolve(`Visual content detected in ${file.name}. This appears to be an image that may contain diagrams, charts, or visual elements that require AI analysis for proper explanation.`);
              } else {
                resolve(extractedText);
      }
            } catch (error) {
              resolve(`Visual content from ${file.name}. This image may contain charts, diagrams, or visual elements. Use the AI Explainer for detailed analysis.`);
            }
          }, 'image/jpeg', 0.8);
        };
        
        img.onerror = () => {
          resolve(`Visual content from ${file.name}. Unable to process image. Please ensure the image is clear and try again.`);
        };
        
        img.src = URL.createObjectURL(file);
      });
    } catch (error) {
      return `Visual content from ${file.name}. This image may contain charts, diagrams, or visual elements. Use the AI Explainer for detailed analysis.`;
    }
  }

  generateSummary(content: string, type: string): string {
    if (!content || content.length < 50) {
      return 'Content available for analysis and reading.';
    }
    
    const sentences = content.split(/[.!?]+/).filter(s => s.length > 10);
    const keyWords = ['important', 'key', 'main', 'summary', 'conclusion', 'result', 'definition', 'concept', 'theory', 'principle'];
    
    const importantSentences = sentences.filter(sentence => 
      keyWords.some(keyword => sentence.toLowerCase().includes(keyword))
    );
    
    if (importantSentences.length > 0) {
      return importantSentences.slice(0, 2).join('. ').trim() + '.';
    }
    
    // Take first few sentences as summary
    const summary = sentences.slice(0, 2).join('. ').trim();
    return summary.length > 150 ? summary.substring(0, 147) + '...' : summary + '.';
  }

  identifyContentType(content: string): string {
    const lowerContent = content.toLowerCase();
    
    // More comprehensive content type detection
    if (lowerContent.includes('chart') || lowerContent.includes('graph') || 
        lowerContent.includes('data') || lowerContent.includes('statistics') ||
        lowerContent.includes('percentage') || lowerContent.includes('%')) {
      return 'chart';
    } else if (lowerContent.includes('diagram') || lowerContent.includes('figure') ||
               lowerContent.includes('process') || lowerContent.includes('flow') ||
               lowerContent.includes('structure') || lowerContent.includes('system')) {
      return 'diagram';
    } else if (lowerContent.includes('table') || lowerContent.includes('row') || 
               lowerContent.includes('column') || lowerContent.includes('cell') ||
               /\|\s*\w+\s*\|/.test(content)) { // Detect table-like structure
      return 'table';
    }
    
    return 'text';
  }
}

export default new FileProcessingService();
