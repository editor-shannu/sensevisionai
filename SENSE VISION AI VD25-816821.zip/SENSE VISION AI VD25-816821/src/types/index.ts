export interface StudyFile {
  id: string;
  name: string;
  type: string;
  size: number;
  uploadedAt: Date;
  content?: string;
  summary?: string;
  audioUrl?: string;
  status: 'processing' | 'ready' | 'error';
  contentType?: 'text' | 'visual';
}

export interface VoiceCommand {
  command: string;
  action: string;
  description: string;
}

export interface TTSSettings {
  language: string;
  voice: string;
  speed: number;
  pitch: number;
  emotion: 'storytelling' | 'instruction' | 'academic';
}

export interface APIResponse {
  success: boolean;
  data?: any;
  error?: string;
}