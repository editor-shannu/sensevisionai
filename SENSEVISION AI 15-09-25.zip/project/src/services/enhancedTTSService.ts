import { TTSSettings } from '../types';
import { saveAs } from 'file-saver';

class EnhancedTTSService {
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private isPlaying: boolean = false;
  private isPaused: boolean = false;
  private currentText: string = '';
  private currentSettings: TTSSettings = {
    language: 'en-US',
    voice: 'default',
    speed: 1.0,
    pitch: 0,
    emotion: 'academic'
  };

  async speak(text: string, settings: TTSSettings): Promise<void> {
    return new Promise((resolve, reject) => {
      try {
        // Stop any current speech
        this.stop();
        
        this.currentText = text;
        this.currentSettings = settings;
        
        if ('speechSynthesis' in window) {
          const utterance = new SpeechSynthesisUtterance(text);
          
          // Configure utterance based on settings
          utterance.lang = settings.language;
          utterance.rate = settings.speed;
          utterance.pitch = (settings.pitch + 10) / 10; // Convert to 0-2 range
          utterance.volume = 1.0;
          
          // Get the best voice for the language
          const voices = speechSynthesis.getVoices();
          const preferredVoice = this.getBestVoice(voices, settings.language);
          if (preferredVoice) {
            utterance.voice = preferredVoice;
          }
          
          // Apply emotion-based adjustments
          this.applyEmotionSettings(utterance, settings.emotion);
          
          utterance.onstart = () => {
            this.isPlaying = true;
            this.isPaused = false;
          };
          
          utterance.onend = () => {
            this.isPlaying = false;
            this.isPaused = false;
            this.currentUtterance = null;
            resolve();
          };
          
          utterance.onerror = (event) => {
            this.isPlaying = false;
            this.isPaused = false;
            this.currentUtterance = null;
            reject(new Error(`Speech synthesis error: ${event.error}`));
          };
          
          utterance.onpause = () => {
            this.isPaused = true;
          };
          
          utterance.onresume = () => {
            this.isPaused = false;
          };
          
          this.currentUtterance = utterance;
          speechSynthesis.speak(utterance);
        } else {
          reject(new Error('Speech synthesis not supported'));
        }
      } catch (error) {
        reject(error);
      }
    });
  }

  pause(): void {
    if (speechSynthesis.speaking && !speechSynthesis.paused) {
      speechSynthesis.pause();
      this.isPaused = true;
    }
  }

  resume(): void {
    if (speechSynthesis.paused) {
      speechSynthesis.resume();
      this.isPaused = false;
    }
  }

  stop(): void {
    speechSynthesis.cancel();
    this.isPlaying = false;
    this.isPaused = false;
    this.currentUtterance = null;
  }

  getPlaybackState(): { isPlaying: boolean; isPaused: boolean } {
    return {
      isPlaying: this.isPlaying,
      isPaused: this.isPaused
    };
  }

  private getBestVoice(voices: SpeechSynthesisVoice[], language: string): SpeechSynthesisVoice | null {
    // First, try to find a voice that exactly matches the language
    let voice = voices.find(v => v.lang === language && v.localService);
    if (voice) return voice;
    
    // Then try to find any voice for the language
    voice = voices.find(v => v.lang === language);
    if (voice) return voice;
    
    // Try to find a voice for the language family (e.g., 'en' for 'en-US')
    const languageFamily = language.split('-')[0];
    voice = voices.find(v => v.lang.startsWith(languageFamily) && v.localService);
    if (voice) return voice;
    
    voice = voices.find(v => v.lang.startsWith(languageFamily));
    if (voice) return voice;
    
    // Fallback to default voice
    return voices.find(v => v.default) || voices[0] || null;
  }

  private applyEmotionSettings(utterance: SpeechSynthesisUtterance, emotion: string): void {
    switch (emotion) {
      case 'storytelling':
        utterance.rate = Math.max(0.5, utterance.rate * 0.9);
        utterance.pitch = Math.min(2, utterance.pitch * 1.1);
        break;
      case 'instruction':
        utterance.rate = Math.max(0.5, utterance.rate * 0.85);
        utterance.pitch = utterance.pitch; // Keep neutral
        break;
      case 'academic':
        utterance.rate = Math.max(0.5, utterance.rate * 0.8);
        utterance.pitch = Math.max(0, utterance.pitch * 0.9);
        break;
    }
  }

  async generateAudioFile(text: string, settings: TTSSettings, fileName: string): Promise<void> {
    try {
      // For now, we'll create a simple audio file using Web Audio API
      // In a real implementation, you would use Google Cloud TTS API
      
      // Create a simple beep as placeholder
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const duration = Math.min(text.length / 10, 300); // Max 5 minutes
      const sampleRate = audioContext.sampleRate;
      const buffer = audioContext.createBuffer(1, duration * sampleRate, sampleRate);
      
      // Generate a simple tone (placeholder for actual TTS audio)
      const data = buffer.getChannelData(0);
      for (let i = 0; i < data.length; i++) {
        data[i] = Math.sin(2 * Math.PI * 440 * i / sampleRate) * 0.1;
      }
      
      // Convert to WAV format
      const wavBuffer = this.audioBufferToWav(buffer);
      const blob = new Blob([wavBuffer], { type: 'audio/wav' });
      
      // Download the file
      saveAs(blob, `${fileName}_audio.wav`);
      
    } catch (error) {
      console.error('Error generating audio file:', error);
      throw new Error('Failed to generate audio file');
    }
  }

  private audioBufferToWav(buffer: AudioBuffer): ArrayBuffer {
    const length = buffer.length;
    const arrayBuffer = new ArrayBuffer(44 + length * 2);
    const view = new DataView(arrayBuffer);
    
    // WAV header
    const writeString = (offset: number, string: string) => {
      for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
      }
    };
    
    writeString(0, 'RIFF');
    view.setUint32(4, 36 + length * 2, true);
    writeString(8, 'WAVE');
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, buffer.sampleRate, true);
    view.setUint32(28, buffer.sampleRate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    writeString(36, 'data');
    view.setUint32(40, length * 2, true);
    
    // Convert float samples to 16-bit PCM
    const data = buffer.getChannelData(0);
    let offset = 44;
    for (let i = 0; i < length; i++) {
      const sample = Math.max(-1, Math.min(1, data[i]));
      view.setInt16(offset, sample * 0x7FFF, true);
      offset += 2;
    }
    
    return arrayBuffer;
  }
}

export default new EnhancedTTSService();