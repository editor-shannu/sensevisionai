import React from 'react';
import { StudyFile } from '../types';
import { FileText, Image, Volume2, Brain } from 'lucide-react';

interface ContentViewerProps {
  file: StudyFile | null;
  onExplain: () => void;
  onRead: () => void;
  isReading: boolean;
}

const ContentViewer: React.FC<ContentViewerProps> = ({
  file,
  onExplain,
  onRead,
  isReading
}) => {
  if (!file) {
    return (
      <div className="flex items-center justify-center h-96 rounded-3xl bg-gradient-to-br from-gray-100 to-gray-200 border-2 border-gray-200 shadow-clay-inset">
        <div className="text-center">
          <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-gray-600 mb-2">No File Selected</h3>
          <p className="text-gray-500">Select a file from your library to view its content</p>
        </div>
      </div>
    );
  }

  const contentType = file.content?.toLowerCase().includes('chart') || 
                     file.content?.toLowerCase().includes('graph') ? 'visual' : 'text';

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-3 rounded-2xl bg-gradient-to-br from-purple-100 to-purple-200 shadow-clay-soft">
            {file.type.startsWith('image/') ? (
              <Image className="w-6 h-6 text-purple-600" />
            ) : (
              <FileText className="w-6 h-6 text-purple-600" />
            )}
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-800">{file.name}</h2>
            <p className="text-gray-600 capitalize">
              {contentType === 'visual' ? 'Visual Content' : 'Text Document'}
            </p>
          </div>
        </div>

        <div className="flex space-x-3">
          <button
            onClick={onExplain}
            className="flex items-center space-x-2 px-6 py-3 rounded-2xl bg-gradient-to-r from-green-200 to-green-300 text-green-700 hover:from-green-300 hover:to-green-400 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300"
            aria-label="Get AI explanation"
          >
            <Brain className="w-5 h-5" />
            <span>Explain</span>
          </button>

          <button
            onClick={onRead}
            disabled={isReading}
            className={`flex items-center space-x-2 px-6 py-3 rounded-2xl font-medium shadow-clay-soft hover:shadow-clay-inset transition-all duration-300 ${
              isReading
                ? 'bg-gradient-to-r from-yellow-200 to-yellow-300 text-yellow-700 animate-pulse'
                : 'bg-gradient-to-r from-blue-200 to-blue-300 text-blue-700 hover:from-blue-300 hover:to-blue-400'
            }`}
            aria-label={isReading ? 'Reading...' : 'Read aloud'}
          >
            <Volume2 className="w-5 h-5" />
            <span>{isReading ? 'Reading...' : 'Read Aloud'}</span>
          </button>
        </div>
      </div>

      {/* Content Display */}
      <div className="p-8 rounded-3xl bg-gradient-to-br from-white to-gray-50 border-2 border-gray-200 shadow-clay-inset">
        {file.summary && (
          <div className="mb-6 p-6 rounded-2xl bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200">
            <h3 className="text-lg font-bold text-blue-800 mb-2">Summary</h3>
            <p className="text-blue-700 leading-relaxed">{file.summary}</p>
          </div>
        )}

        <div className="prose prose-lg max-w-none">
          <div className="whitespace-pre-wrap text-gray-800 leading-relaxed">
            {file.content}
          </div>
        </div>

        {contentType === 'visual' && (
          <div className="mt-6 p-4 rounded-2xl bg-gradient-to-r from-yellow-50 to-orange-50 border border-yellow-200">
            <div className="flex items-center space-x-2 mb-2">
              <Brain className="w-5 h-5 text-orange-600" />
              <span className="font-medium text-orange-700">Visual Content Detected</span>
            </div>
            <p className="text-orange-600 text-sm">
              This appears to contain charts, graphs, or diagrams. Use the "Explain" button for AI-powered visual analysis.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ContentViewer;