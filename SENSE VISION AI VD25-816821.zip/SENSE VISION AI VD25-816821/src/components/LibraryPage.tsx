import React, { useState, useMemo } from 'react';
import { Search, Filter, FileText, Image, Play, Trash2 } from 'lucide-react';
import { StudyFile } from '../types';
import { formatDate } from '../utils/helpers';

interface LibraryPageProps {
  files: StudyFile[];
  onFileSelect: (file: StudyFile) => void;
  onFileDelete: (fileId: string) => void;
}

const LibraryPage: React.FC<LibraryPageProps> = ({ files, onFileSelect, onFileDelete }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'text' | 'visual'>('all');

  const stats = useMemo(() => {
    const textFiles = files.filter(f => f.contentType === 'text' || !f.contentType);
    const visualFiles = files.filter(f => f.contentType === 'visual');
    const analyzedFiles = files.filter(f => f.summary);

    return {
      total: files.length,
      text: textFiles.length,
      visual: visualFiles.length,
      analyzed: analyzedFiles.length
    };
  }, [files]);

  const filteredFiles = useMemo(() => {
    return files.filter(file => {
      const matchesSearch = file.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           (file.summary && file.summary.toLowerCase().includes(searchTerm.toLowerCase()));
      
      const matchesFilter = filterType === 'all' || 
                           (filterType === 'text' && (file.contentType === 'text' || !file.contentType)) ||
                           (filterType === 'visual' && file.contentType === 'visual');

      return matchesSearch && matchesFilter;
    });
  }, [files, searchTerm, filterType]);

  const getFileIcon = (file: StudyFile) => {
    if (file.contentType === 'visual' || file.type.startsWith('image/')) {
      return <Image className="w-6 h-6 text-purple-600" />;
    }
    return <FileText className="w-6 h-6 text-purple-600" />;
  };

  const getFileTypeLabel = (file: StudyFile) => {
    if (file.contentType === 'visual' || file.type.startsWith('image/')) {
      return 'Visual';
    }
    return 'Text';
  };

  return (
    <div className="max-w-6xl mx-auto px-6 py-8">
      {/* Header */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">My Library</h2>
        <p className="text-gray-600">Manage your uploaded study materials</p>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search your materials..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 rounded-2xl border-2 border-gray-200 bg-white shadow-clay-soft focus:shadow-clay-inset focus:border-purple-300 outline-none transition-all duration-200"
          />
        </div>
        
        <div className="relative">
          <Filter className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value as 'all' | 'text' | 'visual')}
            className="pl-12 pr-8 py-3 rounded-2xl border-2 border-gray-200 bg-white shadow-clay-soft focus:shadow-clay-inset focus:border-purple-300 outline-none transition-all duration-200 appearance-none cursor-pointer"
          >
            <option value="all">All Materials</option>
            <option value="text">Text Documents</option>
            <option value="visual">Visual Content</option>
          </select>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <div className="text-center p-4 rounded-2xl bg-white shadow-clay-soft">
          <div className="text-2xl font-bold text-gray-800 mb-1">{stats.total}</div>
          <div className="text-sm text-gray-600">Total Materials</div>
        </div>
        <div className="text-center p-4 rounded-2xl bg-white shadow-clay-soft">
          <div className="text-2xl font-bold text-purple-600 mb-1">{stats.text}</div>
          <div className="text-sm text-gray-600">Text Documents</div>
        </div>
        <div className="text-center p-4 rounded-2xl bg-white shadow-clay-soft">
          <div className="text-2xl font-bold text-blue-600 mb-1">{stats.visual}</div>
          <div className="text-sm text-gray-600">Visual Content</div>
        </div>
        <div className="text-center p-4 rounded-2xl bg-white shadow-clay-soft">
          <div className="text-2xl font-bold text-green-600 mb-1">{stats.analyzed}</div>
          <div className="text-sm text-gray-600">AI Analyzed</div>
        </div>
      </div>

      {/* Files List */}
      <div className="space-y-4">
        {filteredFiles.length === 0 ? (
          <div className="text-center py-16">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-3xl bg-gray-200 shadow-clay-soft mb-4">
              <FileText className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-xl font-bold text-gray-600 mb-2">
              {searchTerm || filterType !== 'all' ? 'No matching files found' : 'No files in your library'}
            </h3>
            <p className="text-gray-500">
              {searchTerm || filterType !== 'all' 
                ? 'Try adjusting your search or filter criteria'
                : 'Upload some study materials to get started'
              }
            </p>
          </div>
        ) : (
          filteredFiles.map((file) => (
            <div
              key={file.id}
              className="bg-white p-6 rounded-3xl shadow-clay-soft hover:shadow-clay-hover transition-all duration-300"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4 flex-1 min-w-0">
                  <div className="p-3 rounded-2xl bg-gradient-to-br from-purple-200 to-purple-300 shadow-clay-soft">
                    {getFileIcon(file)}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-gray-800 truncate mb-1">{file.name}</h3>
                    {file.summary && (
                      <p className="text-gray-600 text-sm line-clamp-2 mb-2">{file.summary}</p>
                    )}
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      <span className="px-2 py-1 rounded-lg bg-purple-100 text-purple-700 font-medium">
                        {getFileTypeLabel(file)}
                      </span>
                      <span>{formatDate(file.uploadedAt)}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 ml-4">
                  <button
                    onClick={() => onFileSelect(file)}
                    className="flex items-center space-x-2 px-4 py-2 rounded-2xl bg-gradient-to-br from-green-200 to-green-300 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300"
                  >
                    <Play className="w-4 h-4 text-green-700" />
                  </button>
                  
                  <button
                    onClick={() => onFileDelete(file.id)}
                    className="flex items-center space-x-2 px-4 py-2 rounded-2xl bg-gradient-to-br from-red-200 to-red-300 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300"
                  >
                    <Trash2 className="w-4 h-4 text-red-700" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default LibraryPage;