import React, { useCallback, useState, useRef } from 'react';
import { useDropzone } from 'react-dropzone';
import { FileText, Image, Upload, Volume2, Mic, Play, Pause, Download, Copy, MicOff, Square } from 'lucide-react';
import { useTextToSpeech } from '../hooks/useTextToSpeech';
import toast from 'react-hot-toast';

interface HomePageProps {
  onFileUpload: (files: File[], type: 'text' | 'visual') => void;
  isProcessing: boolean;
  onNavigate: (page: 'home' | 'reader' | 'explainer' | 'library') => void;
  totalFiles: number;
}

const HomePage: React.FC<HomePageProps> = ({ onFileUpload, isProcessing, onNavigate, totalFiles }) => {
  // Text-to-Audio states
  const [textToConvert, setTextToConvert] = useState('');
  const [isGeneratingAudio, setIsGeneratingAudio] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  
  // Speech-to-Text states
  const [isListening, setIsListening] = useState(false);
  const [transcribedText, setTranscribedText] = useState('');
  const [interimText, setInterimText] = useState('');
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const { speak, pause, resume, isPlaying } = useTextToSpeech();

  const onDropText = useCallback((acceptedFiles: File[]) => {
    onFileUpload(acceptedFiles, 'text');
  }, [onFileUpload]);

  const onDropVisual = useCallback((acceptedFiles: File[]) => {
    onFileUpload(acceptedFiles, 'visual');
  }, [onFileUpload]);

  const { getRootProps: getTextRootProps, getInputProps: getTextInputProps, isDragActive: isTextDragActive } = useDropzone({
    onDrop: onDropText,
    accept: {
      'application/pdf': ['.pdf'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'application/msword': ['.doc'],
      'application/vnd.ms-powerpoint': ['.ppt'],
      'application/vnd.openxmlformats-officedocument.presentationml.presentation': ['.pptx'],
      'text/plain': ['.txt']
    },
    disabled: isProcessing
  });

  const { getRootProps: getVisualRootProps, getInputProps: getVisualInputProps, isDragActive: isVisualDragActive } = useDropzone({
    onDrop: onDropVisual,
    accept: {
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
      'image/gif': ['.gif'],
      'image/bmp': ['.bmp'],
      'image/webp': ['.webp'],
      'image/svg+xml': ['.svg']
    },
    disabled: isProcessing
  });

  // Text-to-Audio Functions
  const handleGenerateAudio = useCallback(async () => {
    if (!textToConvert.trim()) {
      toast.error('Please enter some text to convert');
      return;
    }

    setIsGeneratingAudio(true);
    try {
      if ('speechSynthesis' in window) {
        // Stop any current speech
        speechSynthesis.cancel();
        
        // Wait for voices to be loaded
        const voices = speechSynthesis.getVoices();
        if (voices.length === 0) {
          // Wait for voices to load
          speechSynthesis.addEventListener('voiceschanged', () => {
            const newVoices = speechSynthesis.getVoices();
            if (newVoices.length > 0) {
              generateSpeech(newVoices);
            }
          }, { once: true });
        } else {
          generateSpeech(voices);
        }
        
        function generateSpeech(availableVoices: SpeechSynthesisVoice[]) {
          const utterance = new SpeechSynthesisUtterance(textToConvert);
          utterance.lang = 'en-US';
          utterance.rate = 0.9;
          utterance.pitch = 1.0;
          utterance.volume = 1.0;
          
          // Select best voice
          const preferredVoice = availableVoices.find(voice => 
            voice.lang === 'en-US' && voice.localService
          ) || availableVoices.find(voice => voice.lang === 'en-US') || availableVoices[0];
          
          if (preferredVoice) {
            utterance.voice = preferredVoice;
          }
          
          utterance.onstart = () => {
            setIsGeneratingAudio(false);
            toast.success('Audio generated successfully!');
          };
          
          utterance.onend = () => {
            setIsGeneratingAudio(false);
          };
          
          utterance.onerror = (event) => {
            console.error('Speech synthesis error:', event.error);
            setIsGeneratingAudio(false);
            toast.error('Failed to generate audio');
          };
          
          speechSynthesis.speak(utterance);
        }
        
        // Create downloadable content
        const blob = new Blob([textToConvert], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        setAudioUrl(url);
      } else {
        setIsGeneratingAudio(false);
        toast.error('Speech synthesis not supported in this browser');
      }
    } catch (error) {
      console.error('Audio generation error:', error);
      setIsGeneratingAudio(false);
      toast.error('Failed to generate audio');
    }
  }, [textToConvert]);

  const handlePlayAudio = useCallback(() => {
    if (textToConvert.trim()) {
      if (speechSynthesis.speaking) {
        if (speechSynthesis.paused) {
          speechSynthesis.resume();
          setIsPlayingAudio(true);
        } else {
          speechSynthesis.pause();
          setIsPlayingAudio(false);
        }
      } else {
        speechSynthesis.cancel();
        
        const utterance = new SpeechSynthesisUtterance(textToConvert);
        utterance.lang = 'en-US';
        utterance.rate = 0.9;
        utterance.pitch = 1.0;
        utterance.volume = 1.0;
        
        // Get best voice
        const voices = speechSynthesis.getVoices();
        const preferredVoice = voices.find(voice => 
          voice.lang === 'en-US' && voice.localService
        ) || voices.find(voice => voice.lang === 'en-US') || voices[0];
        
        if (preferredVoice) {
          utterance.voice = preferredVoice;
        }
        
        utterance.onstart = () => setIsPlayingAudio(true);
        utterance.onend = () => setIsPlayingAudio(false);
        utterance.onpause = () => setIsPlayingAudio(false);
        utterance.onresume = () => setIsPlayingAudio(true);
        utterance.onerror = () => setIsPlayingAudio(false);
        
        utteranceRef.current = utterance;
        speechSynthesis.speak(utterance);
      }
    } else {
      toast.error('Please enter some text first');
    }
  }, [textToConvert]);

  const handleStopAudio = useCallback(() => {
    speechSynthesis.cancel();
    setIsPlayingAudio(false);
  }, []);

  const handleDownloadAudio = useCallback(() => {
    if (textToConvert.trim()) {
      // Create a text file with the content
      const content = `Text-to-Audio Content\n\nOriginal Text:\n${textToConvert}\n\nGenerated on: ${new Date().toLocaleString()}`;
      const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = `text-to-audio-${Date.now()}.txt`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      URL.revokeObjectURL(url);
      toast.success('Audio content downloaded!');
    } else {
      toast.error('No content to download');
    }
  }, [textToConvert]);

  // Speech-to-Text Functions
  const handleStartListening = useCallback(() => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      toast.error('Speech recognition not supported in this browser');
      return;
    }

    try {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognition = new SpeechRecognition();

      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';
      recognition.maxAlternatives = 1;

      recognition.onstart = () => {
        setIsListening(true);
        setTranscribedText('');
        setInterimText('');
        toast.success('Listening... Speak now!');
      };

      recognition.onresult = (event) => {
        let finalTranscript = '';
        let interimTranscript = '';
        
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcript;
          } else {
            interimTranscript += transcript;
          }
        }
        
        if (finalTranscript) {
          setTranscribedText(prev => prev + finalTranscript);
        }
        setInterimText(interimTranscript);
      };

      recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        setIsPlayingAudio(false);
        setInterimText('');
        
        if (event.error === 'no-speech') {
          toast.error('No speech detected. Please try again.');
        } else if (event.error === 'network') {
          toast.error('Network error. Please check your connection.');
        } else {
          toast.error('Speech recognition failed. Please try again.');
        }
      };

      recognition.onend = () => {
        setIsListening(false);
        setInterimText('');
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (error) {
      console.error('Speech recognition setup error:', error);
      toast.error('Failed to start speech recognition');
    }
  }, []);

  const handleStopListening = useCallback(() => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
      setInterimText('');
      
      // Auto-read the transcribed text after stopping
      setTimeout(() => {
        if (transcribedText.trim()) {
          toast.success('Speech converted to text! Reading aloud...');
          speak(transcribedText);
        }
      }, 500);
    }
  }, [transcribedText, speak]);

  const handleCopyText = useCallback(() => {
    if (transcribedText.trim()) {
      navigator.clipboard.writeText(transcribedText).then(() => {
        toast.success('Text copied to clipboard!');
      }).catch(() => {
        toast.error('Failed to copy text');
      });
    } else {
      toast.error('No text to copy');
    }
  }, [transcribedText]);

  // Cleanup on unmount
  React.useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      speechSynthesis.cancel();
    };
  }, []);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-4 sm:py-8">
      {/* Welcome Section */}
      <div className="text-center mb-8 sm:mb-12">
        <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-4">
          Welcome to Your Learning Companion
        </h2>
        <p className="text-base sm:text-lg text-gray-600 max-w-2xl mx-auto px-4">
          Upload your study materials and let AI help you learn through accessible audio explanations
        </p>
      </div>

      {/* Upload Sections */}
      <div className="grid sm:grid-cols-2 gap-6 sm:gap-8 mb-8 sm:mb-12">
        {/* Text Documents */}
        <div className="space-y-4">
          <div
            {...getTextRootProps()}
            className={`relative p-6 sm:p-8 rounded-3xl border-3 border-dashed cursor-pointer transition-all duration-300 mobile-touch-target ${
              isTextDragActive
                ? 'border-purple-400 bg-purple-50 shadow-clay-inset'
                : 'border-gray-300 bg-white shadow-clay-soft hover:shadow-clay-hover'
            } ${isProcessing ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            <input {...getTextInputProps()} />
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-br from-purple-200 to-purple-300 shadow-clay-soft mb-4">
                <FileText className="w-6 h-6 sm:w-8 sm:h-8 text-purple-700" />
              </div>
              <h3 className="text-lg sm:text-xl font-bold text-gray-800 mb-2">Text Documents</h3>
              <p className="text-sm sm:text-base text-gray-600 mb-4">
                Upload documents or photos of text to be read aloud.
              </p>
              <div className="text-sm text-gray-500">
                <p>Supported: PDF, TXT, DOC, DOCX, PPT, PPTX</p>
                <p>Max size: 10MB</p>
              </div>
            </div>
          </div>

          {/* Text-to-Audio Feature */}
          <div className="p-6 rounded-3xl bg-white shadow-clay-soft border border-gray-200">
            <div className="flex items-center space-x-3 mb-4">
              <div className="inline-flex items-center justify-center w-10 h-10 rounded-2xl bg-gradient-to-br from-blue-200 to-blue-300 shadow-clay-soft">
                <Volume2 className="w-5 h-5 text-blue-700" />
              </div>
              <h3 className="text-lg font-bold text-gray-800">Text to Audio</h3>
            </div>
            
            <textarea
              value={textToConvert}
              onChange={(e) => setTextToConvert(e.target.value)}
              placeholder="Type or paste your text here to convert to speech..."
              className="w-full h-32 p-4 rounded-2xl border-2 border-gray-200 bg-white focus:border-blue-300 outline-none transition-all duration-200 resize-none text-sm text-gray-800 placeholder-gray-500"
              disabled={isGeneratingAudio}
            />
            
            <div className="flex flex-wrap gap-2 mt-4">
              <button
                onClick={handleGenerateAudio}
                disabled={isGeneratingAudio || !textToConvert.trim()}
                className="flex items-center space-x-2 px-4 py-2 rounded-2xl bg-gradient-to-r from-blue-200 to-blue-300 text-blue-700 hover:from-blue-300 hover:to-blue-400 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed text-sm"
              >
                <Volume2 className="w-4 h-4" />
                <span>{isGeneratingAudio ? 'Generating...' : 'Generate Audio'}</span>
              </button>
              
              <button
                onClick={handlePlayAudio}
                disabled={!textToConvert.trim()}
                className="flex items-center space-x-2 px-4 py-2 rounded-2xl bg-gradient-to-r from-green-200 to-green-300 text-green-700 hover:from-green-300 hover:to-green-400 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed text-sm"
              >
                {speechSynthesis.speaking && !speechSynthesis.paused ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                <span>{speechSynthesis.speaking && !speechSynthesis.paused ? 'Pause' : 'Play'}</span>
              </button>
              
              <button
                onClick={handleStopAudio}
                disabled={!speechSynthesis.speaking}
                className="flex items-center space-x-2 px-4 py-2 rounded-2xl bg-gradient-to-r from-red-200 to-red-300 text-red-700 hover:from-red-300 hover:to-red-400 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed text-sm"
              >
                <Square className="w-4 h-4" />
                <span>Stop</span>
              </button>
              
              <button
                onClick={handleDownloadAudio}
                disabled={!textToConvert.trim()}
                className="flex items-center space-x-2 px-4 py-2 rounded-2xl bg-gradient-to-r from-purple-200 to-purple-300 text-purple-700 hover:from-purple-300 hover:to-purple-400 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed text-sm"
              >
                <Download className="w-4 h-4" />
                <span>Download</span>
              </button>
            </div>
          </div>
        </div>

        {/* Visual Content */}
        <div className="space-y-4">
          <div
            {...getVisualRootProps()}
            className={`relative p-6 sm:p-8 rounded-3xl border-3 border-dashed cursor-pointer transition-all duration-300 mobile-touch-target ${
              isVisualDragActive
                ? 'border-purple-400 bg-purple-50 shadow-clay-inset'
                : 'border-gray-300 bg-white shadow-clay-soft hover:shadow-clay-hover'
            } ${isProcessing ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            <input {...getVisualInputProps()} />
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-br from-purple-200 to-purple-300 shadow-clay-soft mb-4">
                <Image className="w-6 h-6 sm:w-8 sm:h-8 text-purple-700" />
              </div>
              <h3 className="text-lg sm:text-xl font-bold text-gray-800 mb-2">Visual Content</h3>
              <p className="text-sm sm:text-base text-gray-600 mb-4">
                Upload diagrams, graphs, or charts for an AI-powered explanation.
              </p>
              <div className="text-sm text-gray-500">
                <p>Supported: PNG, JPG, GIF, BMP, WebP, SVG</p>
                <p>Max size: 10MB</p>
              </div>
            </div>
          </div>

          {/* Speech-to-Text Feature */}
          <div className="p-6 rounded-3xl bg-white shadow-clay-soft border border-gray-200">
            <div className="flex items-center space-x-3 mb-4">
              <div className="inline-flex items-center justify-center w-10 h-10 rounded-2xl bg-gradient-to-br from-green-200 to-green-300 shadow-clay-soft">
                <Mic className="w-5 h-5 text-green-700" />
              </div>
              <h3 className="text-lg font-bold text-gray-800">Speech to Text</h3>
            </div>
            
            <div className="space-y-4">
              <div className="flex gap-2">
                <button
                  onClick={handleStartListening}
                  disabled={isListening}
                  className="flex items-center space-x-2 px-4 py-2 rounded-2xl bg-gradient-to-r from-green-200 to-green-300 text-green-700 hover:from-green-300 hover:to-green-400 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed text-sm"
                >
                  <Mic className="w-4 h-4" />
                  <span>{isListening ? 'Listening...' : 'Start Listening'}</span>
                </button>
                
                <button
                  onClick={handleStopListening}
                  disabled={!isListening}
                  className="flex items-center space-x-2 px-4 py-2 rounded-2xl bg-gradient-to-r from-red-200 to-red-300 text-red-700 hover:from-red-300 hover:to-red-400 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed text-sm"
                >
                  <MicOff className="w-4 h-4" />
                  <span>Stop Listening</span>
                </button>
              </div>
              
              {(isListening || transcribedText || interimText) && (
                <div className="space-y-3">
                  {isListening && (
                    <div className="flex items-center space-x-2 text-green-600 text-sm">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                      <span>Listening... Speak now!</span>
                    </div>
                  )}
                  
                  {(transcribedText || interimText) && (
                    <div className="space-y-2">
                      <textarea
                        value={transcribedText + (interimText ? ' ' + interimText : '')}
                        readOnly
                        className="w-full h-24 p-3 rounded-2xl border-2 border-gray-200 bg-white text-sm resize-none text-gray-800"
                        placeholder="Your transcribed text will appear here..."
                      />
                      {transcribedText && (
                        <button
                        onClick={handleCopyText}
                        className="flex items-center space-x-2 px-4 py-2 rounded-2xl bg-gradient-to-r from-blue-200 to-blue-300 text-blue-700 hover:from-blue-300 hover:to-blue-400 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300 text-sm"
                      >
                        <Copy className="w-4 h-4" />
                        <span>Copy Text</span>
                      </button>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Accessibility Features */}
      <div>
        <h3 className="text-lg sm:text-xl font-bold text-gray-800 mb-4 sm:mb-6">Accessibility Features</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
          <div className="text-center p-4 sm:p-6 rounded-3xl bg-white shadow-clay-soft">
            <div className="inline-flex items-center justify-center w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-br from-blue-200 to-blue-300 shadow-clay-soft mb-4">
              <span className="text-blue-700 font-bold">TTS</span>
            </div>
            <h4 className="text-sm sm:text-base font-bold text-gray-800 mb-2">Text-to-Speech</h4>
            <p className="text-sm text-gray-600">Natural voice reading</p>
          </div>
          
          <div className="text-center p-4 sm:p-6 rounded-3xl bg-white shadow-clay-soft">
            <div className="inline-flex items-center justify-center w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-br from-green-200 to-green-300 shadow-clay-soft mb-4">
              <span className="text-green-700 font-bold">AI</span>
            </div>
            <h4 className="text-sm sm:text-base font-bold text-gray-800 mb-2">AI Explanations</h4>
            <p className="text-sm text-gray-600">Smart content analysis</p>
          </div>
          
          <div className="text-center p-4 sm:p-6 rounded-3xl bg-white shadow-clay-soft">
            <div className="inline-flex items-center justify-center w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-br from-purple-200 to-purple-300 shadow-clay-soft mb-4">
              <span className="text-purple-700 font-bold">ML</span>
            </div>
            <h4 className="text-sm sm:text-base font-bold text-gray-800 mb-2">Multi-language</h4>
            <p className="text-sm text-gray-600">English, Hindi, Telugu</p>
          </div>
        </div>
      </div>

      {/* Processing Indicator */}
      {isProcessing && (
        <div className="fixed inset-0 bg-black/20 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white p-6 sm:p-8 rounded-3xl shadow-clay-soft max-w-sm w-full">
            <div className="flex items-center space-x-4">
              <div className="animate-spin rounded-full h-8 w-8 border-4 border-purple-300 border-t-purple-600"></div>
              <span className="text-base sm:text-lg font-medium text-gray-800">Processing files...</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default HomePage;