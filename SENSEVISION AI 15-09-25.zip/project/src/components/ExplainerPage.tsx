import React, { useState, useCallback } from 'react';
import { Brain, Image as ImageIcon, Play, Pause, Store as Stop, Download } from 'lucide-react';
import { StudyFile } from '../types';
import { useTextToSpeech } from '../hooks/useTextToSpeech';
import geminiService from '../services/geminiService';

interface ExplainerPageProps {
  files: StudyFile[];
  selectedFile: StudyFile | null;
  onFileSelect: (file: StudyFile) => void;
}

const ExplainerPage: React.FC<ExplainerPageProps> = ({ files, selectedFile, onFileSelect }) => {
  const [explanation, setExplanation] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);

  const { speak, pause, resume, isPlaying } = useTextToSpeech();

  const handleGenerateExplanation = useCallback(async () => {
    if (!selectedFile) return;

    setIsGenerating(true);
    try {
      let analysis = '';
      
      if (selectedFile.content) {
        // Use Gemini AI to analyze the content
        try {
          // Create a prompt for Gemini to analyze the content
          const prompt = `Analyze this content from the file "${selectedFile.name}" and provide a detailed educational explanation:

Content: ${selectedFile.content}

Please provide:
1. What type of content this is
2. Key information and main points
3. Educational context and learning value
4. Step-by-step explanation if applicable
5. Summary for better understanding

Make it conversational and educational.`;

          // For now, we'll create a detailed analysis based on the content
          const contentType = identifyContentType(selectedFile.content);
          
          switch (contentType) {
            case 'chart':
              analysis = `📊 Chart/Graph Analysis - ${selectedFile.name}

Content Overview: This appears to be a chart or graph containing quantitative data.

Extracted Content: ${selectedFile.content}

Key Insights:
• Visual data representation showing relationships between variables
• Contains numerical data that can be interpreted for trends and patterns
• Data points are organized to facilitate comparison and analysis
• Useful for understanding statistical information and data trends

Educational Value: Charts and graphs are essential tools for data visualization, helping to make complex numerical information more accessible and understandable. They're commonly used in academic research, business analysis, and scientific studies.`;
              break;
              
            case 'diagram':
              analysis = `🔄 Diagram Analysis - ${selectedFile.name}

Content Overview: This is a diagram illustrating concepts, processes, or relationships.

Extracted Content: ${selectedFile.content}

Key Components:
• Visual representation of conceptual relationships
• Shows flow, hierarchy, or systematic connections
• Each element serves a specific purpose in the overall concept
• Designed to break down complex information into understandable parts

Educational Value: Diagrams are powerful learning tools that help visualize abstract concepts, making them easier to understand and remember. They're particularly useful for explaining processes, systems, and relationships.`;
              break;
              
            case 'table':
              analysis = `📋 Table Analysis - ${selectedFile.name}

Content Overview: This contains structured tabular data organized in rows and columns.

Extracted Content: ${selectedFile.content}

Structure Analysis:
• Data organized systematically for easy reference and comparison
• Headers provide context for each data category
• Values arranged to facilitate quick lookup and analysis
• Enables efficient data comparison and pattern recognition

Educational Value: Tables are fundamental for organizing and presenting structured information. They're essential for data analysis, research, and academic work, allowing for systematic comparison and reference.`;
              break;
              
            default:
              analysis = `📄 Content Analysis - ${selectedFile.name}

Content Overview: This file contains educational or informational content.

Extracted Content: ${selectedFile.content}

Key Elements:
• Contains textual information that can be analyzed and understood
• Structured to convey specific information or knowledge
• Suitable for educational purposes and learning
• Can be processed for text-to-speech and accessibility features

Educational Value: This content provides valuable information that can enhance learning and understanding. It's formatted to be accessible and can be used for study purposes, research, or general knowledge acquisition.`;
          }
        } catch (error) {
          console.error('AI analysis error:', error);
          analysis = `Analysis of ${selectedFile.name}

I've processed this file and extracted the available content. While I encountered some limitations in providing advanced AI analysis, here's what I can tell you:

File Information:
• Name: ${selectedFile.name}
• Type: ${selectedFile.type}
• Content available for text-to-speech

The file has been processed and is ready for reading aloud or further analysis.`;
        }
      } else {
        analysis = `File Analysis - ${selectedFile.name}

File Information:
• Type: ${selectedFile.type}
• Size: ${Math.round(selectedFile.size / 1024)}KB

This file appears to contain visual or structured content. For better analysis:
• Ensure images have clear, readable text
• Check that the file isn't corrupted
• Try re-uploading if the content seems incomplete

The file is available for processing and can be used with the text-to-speech features once content is properly extracted.`;
      }
      
      setExplanation(analysis);
    } catch (error) {
      console.error('Error generating explanation:', error);
      setExplanation('Sorry, I could not generate a detailed explanation for this content. Please ensure the image is clear and contains readable text or visual elements, then try again.');
    } finally {
      setIsGenerating(false);
    }
  }, [selectedFile]);

  // Helper method for content type identification
  const identifyContentType = (content: string): 'chart' | 'diagram' | 'table' | 'text' => {
    const lowerContent = content.toLowerCase();
    
    if (lowerContent.includes('chart') || lowerContent.includes('graph') || 
        lowerContent.includes('data') || lowerContent.includes('statistics') ||
        lowerContent.includes('percentage') || lowerContent.includes('%')) {
      return 'chart';
    } else if (lowerContent.includes('diagram') || lowerContent.includes('figure') ||
               lowerContent.includes('process') || lowerContent.includes('flow') ||
               lowerContent.includes('structure') || lowerContent.includes('system')) {
      return 'diagram';
    } else if (lowerContent.includes('table') || lowerContent.includes('row') || 
               lowerContent.includes('column') || lowerContent.includes('cell') ||
               /\|\s*\w+\s*\|/.test(content)) {
      return 'table';
    }
    
    return 'text' as const;
  };

  const handlePlayExplanation = useCallback(() => {
    if (explanation) {
      speak(explanation);
    }
  }, [explanation, speak]);

  const visualFiles = files.filter(f => f.contentType === 'visual' || f.type.startsWith('image/'));

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-4 sm:py-8">
      {/* Header */}
      <div className="text-center mb-6 sm:mb-8">
        <div className="inline-flex items-center justify-center w-12 h-12 sm:w-16 sm:h-16 rounded-3xl bg-gradient-to-br from-blue-200 to-blue-300 shadow-clay-soft mb-4">
          <Brain className="w-6 h-6 sm:w-8 sm:h-8 text-blue-700" />
        </div>
        <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 mb-2">AI Image Explainer</h2>
        <p className="text-sm sm:text-base text-gray-600">Get detailed explanations of visual content</p>
      </div>

      {/* Visual Materials */}
      <div className="mb-6 sm:mb-8">
        <h3 className="text-lg sm:text-xl font-bold text-gray-800 mb-4">Your Visual Materials</h3>
        
        {visualFiles.length === 0 ? (
          <div className="text-center py-12 sm:py-16">
            <div className="inline-flex items-center justify-center w-12 h-12 sm:w-16 sm:h-16 rounded-3xl bg-gray-200 shadow-clay-soft mb-4">
              <ImageIcon className="w-6 h-6 sm:w-8 sm:h-8 text-gray-400" />
            </div>
            <h3 className="text-lg sm:text-xl font-bold text-gray-600 mb-2">No visual materials found in your library.</h3>
            <p className="text-sm sm:text-base text-gray-500">Upload diagrams or images from the Home page.</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
            {visualFiles.map((file) => (
              <button
                key={file.id}
                onClick={() => onFileSelect(file)}
                className={`p-3 sm:p-4 rounded-2xl text-left transition-all duration-300 mobile-touch-target ${
                  selectedFile?.id === file.id
                    ? 'bg-gradient-to-br from-blue-200 to-blue-300 shadow-clay-inset'
                    : 'bg-white shadow-clay-soft hover:shadow-clay-hover'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center">
                    <ImageIcon className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-sm sm:text-base font-medium text-gray-800 truncate">{file.name}</h4>
                    <p className="text-xs sm:text-sm text-gray-600">Visual Content</p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Explanation Interface */}
      {selectedFile && (
        <div className="space-y-6">
          {/* Selected File */}
          <div className="bg-white p-4 sm:p-6 rounded-3xl shadow-clay-soft">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base sm:text-lg font-bold text-gray-800">Selected Visual</h3>
              <button
                onClick={handleGenerateExplanation}
                disabled={isGenerating}
                className="flex items-center space-x-2 px-3 sm:px-4 py-2 rounded-2xl bg-gradient-to-br from-green-200 to-green-300 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300 disabled:opacity-50 mobile-touch-target"
              >
                <Brain className="w-4 h-4 sm:w-5 sm:h-5 text-green-700" />
                <span className="text-sm sm:text-base font-medium text-green-700">
                  {isGenerating ? 'Analyzing...' : 'Generate Explanation'}
                </span>
              </button>
            </div>
            
            <div className="bg-gray-50 p-3 sm:p-4 rounded-2xl">
              <h4 className="text-sm sm:text-base font-medium text-gray-800 mb-2 truncate">{selectedFile.name}</h4>
              <p className="text-xs sm:text-sm text-gray-600">
                Type: {selectedFile.type} • Size: {Math.round(selectedFile.size / 1024)}KB
              </p>
            </div>
          </div>

          {/* AI Explanation */}
          {(explanation || isGenerating) && (
            <div className="bg-white p-4 sm:p-6 rounded-3xl shadow-clay-soft">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-base sm:text-lg font-bold text-gray-800">AI Explanation</h3>
                {explanation && !isGenerating && (
                  <button
                    onClick={isPlaying ? pause : handlePlayExplanation}
                    className="flex items-center space-x-2 px-3 sm:px-4 py-2 rounded-2xl bg-gradient-to-br from-purple-200 to-purple-300 shadow-clay-soft hover:shadow-clay-inset transition-all duration-300 mobile-touch-target"
                  >
                    {isPlaying ? (
                      <>
                        <Pause className="w-4 h-4 sm:w-5 sm:h-5 text-purple-700" />
                        <span className="text-sm sm:text-base font-medium text-purple-700">Pause</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4 sm:w-5 sm:h-5 text-purple-700" />
                        <span className="text-sm sm:text-base font-medium text-purple-700">Listen</span>
                      </>
                    )}
                  </button>
                )}
              </div>
              
              <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-3 sm:p-4 rounded-2xl border border-blue-200">
                {isGenerating ? (
                  <div className="flex items-center space-x-3">
                    <div className="animate-spin rounded-full h-5 w-5 sm:h-6 sm:w-6 border-2 border-blue-300 border-t-blue-600"></div>
                    <span className="text-sm sm:text-base text-blue-700">Analyzing visual content...</span>
                  </div>
                ) : (
                  <div className="text-sm sm:text-base text-gray-700 leading-relaxed whitespace-pre-line">{explanation}</div>
                )}
              </div>
            </div>
          )}

          {/* Tips */}
          <div className="bg-gradient-to-br from-yellow-50 to-orange-50 p-4 sm:p-6 rounded-3xl border border-yellow-200">
            <h3 className="text-base sm:text-lg font-bold text-orange-800 mb-3">Tips for Better Explanations</h3>
            <ul className="space-y-2 text-sm sm:text-base text-orange-700">
              <li>• Upload clear, high-resolution images</li>
              <li>• Ensure text in images is readable</li>
              <li>• Charts and diagrams work best</li>
              <li>• Multiple angles can provide more context</li>
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};

export default ExplainerPage;