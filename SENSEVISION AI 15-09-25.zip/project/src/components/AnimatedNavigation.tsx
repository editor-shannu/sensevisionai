import React, { useEffect } from 'react';
import { Home, BookOpen, Brain, Library } from 'lucide-react';

interface AnimatedNavigationProps {
  currentPage: 'home' | 'reader' | 'explainer' | 'library';
  onNavigate: (page: 'home' | 'reader' | 'explainer' | 'library') => void;
}

const AnimatedNavigation: React.FC<AnimatedNavigationProps> = ({ currentPage, onNavigate }) => {
  useEffect(() => {
    // Load GSAP if not already loaded
    if (typeof window !== 'undefined' && !window.gsap) {
      const script = document.createElement('script');
      script.src = 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.3.3/gsap.min.js';
      script.onload = () => {
        console.log('GSAP loaded');
      };
      document.head.appendChild(script);
    }
  }, []);

  const move = (id: string, position: string, color: string, page: 'home' | 'reader' | 'explainer' | 'library') => {
    onNavigate(page);
    
    if (typeof window !== 'undefined' && window.gsap) {
      const tl = window.gsap.timeline();
      tl.to("#bgBubble", {duration: 0.15, bottom: "-30px", ease: "ease-out"}, 0)
        .to("#bubble1", {duration: 0.1, y: "120%", boxShadow: 'none', ease: "ease-out"}, 0)
        .to("#bubble2", {duration: 0.1, y: "120%", boxShadow: 'none', ease: "ease-out"}, 0)
        .to("#bubble3", {duration: 0.1, y: "120%", boxShadow: 'none', ease: "ease-out"}, 0)
        .to("#bubble4", {duration: 0.1, y: "120%", boxShadow: 'none', ease: "ease-out"}, 0)
        .to(".nav-icon", {duration: 0.05, opacity: 0, ease: "ease-out"}, 0)
        .to("#bgBubble", {duration: 0.2, left: position, ease: "ease-in-out"}, 0.1)
        .to("#bgBubble", {duration: 0.15, bottom: "-50px", ease: "ease-out"}, '-=0.2')
        .to(`#bubble${id}`, {duration: 0.15, y: "0%", opacity: 1, boxShadow: '0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24)', ease: "ease-out"}, '-=0.1')
        .to(`#bubble${id} > span`, {duration: 0.15, y: "0%", opacity: 0.7, ease: "ease-out"}, '-=0.1')
        .to("#navbarContainer", {duration: 0.3, backgroundColor: color, ease: "ease-in-out"}, 0)
        .to("#navBg", {duration: 0.3, backgroundColor: color, ease: "ease-in-out"}, 0)
        .to("#bgBubble", {duration: 0.3, backgroundColor: color, ease: "ease-in-out"}, 0);
    }
  };

  const getActiveIndex = () => {
    switch (currentPage) {
      case 'home': return '1';
      case 'reader': return '2';
      case 'explainer': return '3';
      case 'library': return '4';
      default: return '1';
    }
  };

  return (
    <>
      <style>{`
        .animated-nav-container {
          position: fixed;
          bottom: 0;
          left: 0;
          right: 0;
          z-index: 1000;
        }
        
        #navbarContainer {
          width: 100%;
          max-width: 400px;
          height: 80px;
          background-color: #8b5cf6;
          border-radius: 20px 20px 0 0;
          display: flex;
          justify-content: flex-end;
          flex-direction: column;
          overflow: hidden;
          position: relative;
          margin: 0 auto;
          box-shadow: 0 -5px 20px rgba(0, 0, 0, 0.15);
        }

        #navbar {
          width: 100%;
          height: 60px;
          background-color: rgba(255, 255, 255, 0.95);
          position: absolute;
          backdrop-filter: blur(10px);
        }

        #bubbleWrapper {
          position: absolute;
          display: flex;
          justify-content: space-around;
          width: 100%;
          bottom: 25px;
          padding: 0 20px;
        }

        .bubble {
          background-color: #fff;
          width: 50px;
          height: 50px;
          border-radius: 50%;
          z-index: 1;
          transform: translateY(120%);
          display: flex;
          justify-content: center;
          align-items: center;
          box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .nav-icon {
          opacity: 0;
          color: #8b5cf6;
        }

        #bubble1 {
          transform: translateY(0%);
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.24);
        }
        #bubble1 > span {
          opacity: 0.7;
        }

        #bgWrapper {
          filter: url(#goo);
          width: 100%;
          height: 100px;
          position: absolute;
          bottom: 60px;
        }

        #navBg {
          background-color: #8b5cf6;
          width: 120%;
          height: 100%;
          margin-left: -10%;
        }

        #bgBubble {
          position: absolute;
          background-color: #8b5cf6;
          width: 70px;
          height: 70px;
          border-radius: 50%;
          bottom: -50px;
          left: 50px;
          transform: translateX(-50%);
        }

        #menuWrapper {
          position: absolute;
          width: 100%;
          display: flex;
          justify-content: space-around;
          padding: 0 20px;
          bottom: 10px;
        }

        .menuElement {
          opacity: 0.6;
          cursor: pointer;
          padding: 15px;
          border-radius: 50%;
          transition: all 0.3s ease;
          color: #6b7280;
          position: relative;
        }
        .menuElement:hover {
          opacity: 0.8;
          background-color: rgba(139, 92, 246, 0.1);
        }
        .menuElement.active {
          opacity: 1;
          color: #8b5cf6;
        }
        
        .menuElement:hover::after {
          content: attr(title);
          position: absolute;
          bottom: -30px;
          left: 50%;
          transform: translateX(-50%);
          background: rgba(0, 0, 0, 0.8);
          color: white;
          padding: 4px 8px;
          border-radius: 4px;
          font-size: 12px;
          white-space: nowrap;
          z-index: 1000;
        }

        @media (max-width: 768px) {
          #navbarContainer {
            max-width: 100%;
            border-radius: 0;
          }
          
          .bubble {
            width: 45px;
            height: 45px;
          }
          
          .menuElement {
            padding: 12px;
          }
        }
      `}</style>

      <div className="animated-nav-container">
        <div id="navbarContainer">
          <div id="navbar">
            <div id="bubbleWrapper">
              <div id="bubble1" className="bubble">
                <span className="nav-icon">
                  <Home size={20} />
                </span>
              </div>
              <div id="bubble2" className="bubble">
                <span className="nav-icon">
                  <BookOpen size={20} />
                </span>
              </div>
              <div id="bubble3" className="bubble">
                <span className="nav-icon">
                  <Brain size={20} />
                </span>
              </div>
              <div id="bubble4" className="bubble">
                <span className="nav-icon">
                  <Library size={20} />
                </span>
              </div>
            </div>
            <div id="menuWrapper">
              <div 
                className={`menuElement ${currentPage === 'home' ? 'active' : ''}`}
                onClick={() => move('1', '50px', '#8b5cf6', 'home')}
              >
                <Home size={24} />
              </div>
              <div 
                className={`menuElement ${currentPage === 'reader' ? 'active' : ''}`}
                onClick={() => move('2', '150px', '#06b6d4', 'reader')}
            title="Home"
              >
                <BookOpen size={24} />
            <span className="sr-only">Home</span>
              </div>
              <div 
                className={`menuElement ${currentPage === 'explainer' ? 'active' : ''}`}
                onClick={() => move('3', '250px', '#10b981', 'explainer')}
            title="Reader"
              >
                <Brain size={24} />
            <span className="sr-only">Reader</span>
              </div>
              <div 
                className={`menuElement ${currentPage === 'library' ? 'active' : ''}`}
                onClick={() => move('4', '350px', '#f59e0b', 'library')}
            title="Explainer"
              >
                <Library size={24} />
            <span className="sr-only">Explainer</span>
              </div>
            </div>
          </div>
          <div id="bgWrapper">
            title="Library"
            <div id="navBg"></div>
            <div id="bgBubble"></div>
            <span className="sr-only">Library</span>
          </div>
        </div>

        <svg width="0" height="0">
          <defs>
            <filter id="goo">
              <feGaussianBlur in="SourceGraphic" stdDeviation="20" result="blur" />
              <feColorMatrix in="blur" mode="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 30 -15" result="goo" />
              <feComposite in="SourceGraphic" in2="goo" operator="atop"/>
            </filter>
          </defs>
        </svg>
      </div>
    </>
  );
};

// Add GSAP to window type
declare global {
  interface Window {
    gsap: any;
  }
}

export default AnimatedNavigation;