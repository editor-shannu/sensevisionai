import { TTSSettings, APIResponse } from '../types';

class GoogleCloudService {
  private apiKey: string = 'AIzaSyBQJ8K8K8K8K8K8K8K8K8K8K8K8K8K8K8K'; // Replace with actual key

  async extractTextFromImage(imageBase64: string, language: string = 'en'): Promise<APIResponse> {
    try {
      const response = await fetch(`https://vision.googleapis.com/v1/images:annotate?key=${this.apiKey}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          requests: [{
            image: { content: imageBase64 },
            features: [
              { type: 'TEXT_DETECTION', maxResults: 1 },
              { type: 'DOCUMENT_TEXT_DETECTION', maxResults: 1 }
            ],
            imageContext: {
              languageHints: [language, 'en', 'hi', 'te']
            }
          }]
        })
      });

      const data = await response.json();
      
      if (data.responses && data.responses[0] && data.responses[0].textAnnotations) {
        const extractedText = data.responses[0].textAnnotations[0].description;
        return { success: true, data: extractedText };
      }
      
      return { success: false, error: 'No text found in image' };
    } catch (error) {
      console.error('Google Vision OCR error:', error);
      return { success: false, error: `OCR failed: ${error}` };
    }
  }

  async textToSpeech(text: string, settings: TTSSettings): Promise<APIResponse> {
    try {
      const response = await fetch(`https://texttospeech.googleapis.com/v1/text:synthesize?key=${this.apiKey}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          input: { text: text },
          voice: {
            languageCode: settings.language,
            name: this.getBestVoiceName(settings.language),
            ssmlGender: 'NEUTRAL'
          },
          audioConfig: {
            audioEncoding: 'MP3',
            speakingRate: settings.speed,
            pitch: settings.pitch,
            volumeGainDb: 0
          }
        })
      });

      const data = await response.json();
      
      if (data.audioContent) {
        const audioBlob = new Blob([Uint8Array.from(atob(data.audioContent), c => c.charCodeAt(0))], 
          { type: 'audio/mp3' });
        const audioUrl = URL.createObjectURL(audioBlob);
        return { success: true, data: { audioUrl, audioBlob } };
      }
      
      return { success: false, error: 'Failed to generate audio' };
    } catch (error) {
      console.error('Google TTS error:', error);
      return { success: false, error: `TTS failed: ${error}` };
    }
  }

  private getBestVoiceName(languageCode: string): string {
    const voiceMap: { [key: string]: string } = {
      'en-US': 'en-US-Standard-A',
      'hi-IN': 'hi-IN-Standard-A',
      'te-IN': 'te-IN-Standard-A'
    };
    return voiceMap[languageCode] || 'en-US-Standard-A';
  }
}

export default new GoogleCloudService();