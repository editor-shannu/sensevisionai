import { StudyFile, APIResponse } from '../types';
import mammoth from 'mammoth';
import { getDocument } from 'pdfjs-dist';
import googleCloudService from './googleCloudService';
import geminiService from './geminiService';

class EnhancedFileProcessingService {
  async processFile(file: File): Promise<APIResponse> {
    try {
      console.log(`Processing ${file.name}...`);
      
      const studyFile: StudyFile = {
        id: crypto.randomUUID(),
        name: file.name,
        type: file.type,
        size: file.size,
        uploadedAt: new Date(),
        status: 'processing',
        contentType: this.determineContentType(file)
      };

      let content = '';
      
      try {
        // Process files based on type with enhanced error handling
        switch (file.type) {
          case 'application/pdf':
            content = await this.extractPDFText(file);
            break;
          case 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
          case 'application/msword':
            content = await this.extractDocxText(file);
            break;
          case 'text/plain':
            content = await this.extractPlainText(file);
            break;
          case 'application/vnd.ms-powerpoint':
          case 'application/vnd.openxmlformats-officedocument.presentationml.presentation':
            content = await this.extractPresentationText(file);
            break;
          default:
            if (file.type.startsWith('image/')) {
              content = await this.extractImageText(file);
            } else {
              // Try to read as text for unknown types
              content = await this.extractPlainText(file);
            }
        }

        studyFile.content = content;
        studyFile.status = 'ready';
        
        // Generate summary based on content
        if (content && content.length > 50) {
          studyFile.summary = this.generateSummary(content, studyFile.contentType || 'text');
        }
        
        return { success: true, data: studyFile };
      } catch (processingError) {
        console.error('File processing error:', processingError);
        studyFile.status = 'error';
        studyFile.content = `Error processing ${file.name}. The file may be corrupted or in an unsupported format.`;
        return { success: true, data: studyFile };
      }
    } catch (error) {
      return { success: false, error: `File processing failed: ${error}` };
    }
  }

  private determineContentType(file: File): 'text' | 'visual' {
    if (file.type.startsWith('image/')) {
      return 'visual';
    }
    
    const textTypes = [
      'application/pdf',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/msword',
      'application/vnd.ms-powerpoint',
      'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      'text/plain'
    ];
    
    return textTypes.includes(file.type) ? 'text' : 'text';
  }

  private async extractPDFText(file: File): Promise<string> {
    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await getDocument({ data: arrayBuffer }).promise;
      let text = '';
      const maxPages = Math.min(pdf.numPages, 50);
      
      for (let i = 1; i <= maxPages; i++) {
        try {
          const page = await pdf.getPage(i);
          const textContent = await page.getTextContent();
          const pageText = textContent.items
            .map((item: any) => item.str)
            .join(' ');
          text += pageText + '\n\n';
        } catch (pageError) {
          console.warn(`Error processing page ${i}:`, pageError);
          text += `[Page ${i} could not be processed]\n\n`;
        }
      }
      
      return text.trim() || `PDF document: ${file.name}. Content could not be extracted.`;
    } catch (error) {
      throw new Error(`PDF processing failed: ${error}`);
    }
  }

  private async extractDocxText(file: File): Promise<string> {
    try {
      const arrayBuffer = await file.arrayBuffer();
      const result = await mammoth.extractRawText({ arrayBuffer });
      return result.value || `Word document: ${file.name}. Content could not be extracted.`;
    } catch (error) {
      throw new Error(`DOCX processing failed: ${error}`);
    }
  }

  private async extractPresentationText(file: File): Promise<string> {
    try {
      console.log('Processing PowerPoint file:', file.name);
      const arrayBuffer = await file.arrayBuffer();
      
      // Try to extract text from PowerPoint files
      // This is a simplified approach - in production, you'd use a proper PPT parser
      const uint8Array = new Uint8Array(arrayBuffer);
      let textContent = '';
      
      // Look for readable text in the binary data
      const decoder = new TextDecoder('utf-8', { fatal: false });
      const chunkSize = 2048; // Larger chunks for better text extraction
      
      for (let i = 0; i < uint8Array.length; i += chunkSize) {
        try {
          const chunk = uint8Array.slice(i, Math.min(i + chunkSize, uint8Array.length));
          const decodedText = decoder.decode(chunk);
          
          // Extract readable text (alphanumeric + common punctuation)
          const readableText = decodedText.match(/[a-zA-Z0-9\s.,!?;:'"()\-_]{4,}/g);
          
          if (readableText) {
            textContent += readableText.join(' ') + ' ';
          }
        } catch (chunkError) {
          // Skip problematic chunks
          continue;
        }
      }
      
      // Clean up the extracted text
      textContent = textContent
        .replace(/\s+/g, ' ') // Replace multiple spaces with single space
        .replace(/[^\w\s.,!?;:'"()\-]/g, '') // Remove special characters except common punctuation
        .trim();
      
      // Filter out very short or nonsensical text
      const sentences = textContent.split(/[.!?]+/).filter(sentence => {
        const cleaned = sentence.trim();
        return cleaned.length > 10 && /[a-zA-Z]/.test(cleaned);
      });
      
      if (sentences.length > 0) {
        const meaningfulText = sentences.slice(0, 20).join('. '); // Take first 20 meaningful sentences
        
        if (meaningfulText.length > 50) {
          return `PowerPoint Presentation: ${file.name}

Extracted Content:
${meaningfulText}

Note: This is a PowerPoint presentation with multiple slides. The above content represents the text extracted from the slides.`;
        }
      }
      
      // Fallback if no meaningful text was extracted
      return `PowerPoint Presentation: ${file.name}

This PowerPoint file contains ${Math.round(file.size / 1024)}KB of presentation data with slides, images, and formatting.

Content Summary:
• This is a presentation file with multiple slides
• May contain text, images, charts, and other visual elements
• The file has been processed and is ready for analysis
• For better text extraction, consider converting to PDF format

Note: PowerPoint files contain complex formatting and embedded objects. For optimal text extraction, please convert your presentation to PDF format before uploading.`;
      
    } catch (error) {
      console.error('PPT processing error:', error);
      return `PowerPoint Presentation: ${file.name}

Processing Information:
• File size: ${Math.round(file.size / 1024)}KB
• This presentation file has been uploaded successfully
• Contains slides with potential text and visual content
• Ready for text-to-speech functionality

Note: There was an issue extracting detailed text from this PowerPoint file. For better results, try converting the presentation to PDF format before uploading.`;
    }
  }

  private async extractPlainText(file: File): Promise<string> {
    try {
      const text = await file.text();
      
      if (text.length > 200000) {
        const truncated = text.substring(0, 200000);
        return truncated + '\n\n[Note: Large file truncated for performance]';
      }
      
      return text || `Text file: ${file.name}. No readable content found.`;
    } catch (error) {
      throw new Error(`Text file processing failed: ${error}`);
    }
  }

  private async extractImageText(file: File): Promise<string> {
    try {
      // Convert image to base64
      const base64 = await this.fileToBase64(file);
      
      // Use Google Vision OCR for better multilingual support
      const ocrResult = await googleCloudService.extractTextFromImage(base64, 'te');
      
      if (ocrResult.success && ocrResult.data && ocrResult.data.length > 10) {
        return ocrResult.data;
      }
      
      return `Visual content from ${file.name}. This image contains visual elements that can be analyzed with AI explanation.`;
    } catch (error) {
      console.error('Image OCR error:', error);
      return `Visual content from ${file.name}. This image contains visual elements that can be analyzed.`;
    }
  }

  private async fileToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        resolve(result.split(',')[1]);
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  generateSummary(content: string, type: string): string {
    if (!content || content.length < 50) {
      return 'Content available for analysis and reading.';
    }
    
    const cleanContent = content.replace(/\s+/g, ' ').trim();
    const sentences = cleanContent.split(/[.!?]+/).filter(s => s.trim().length > 15);
    
    if (sentences.length === 0) {
      return 'Content available for analysis and reading.';
    }
    
    const keyWords = [
      'important', 'key', 'main', 'summary', 'conclusion', 'result', 'therefore', 
      'because', 'definition', 'concept', 'theory', 'principle', 'objective'
    ];
    
    const importantSentences = sentences.filter(sentence => 
      keyWords.some(keyword => sentence.toLowerCase().includes(keyword))
    );
    
    let summary = '';
    
    if (importantSentences.length > 0) {
      summary = importantSentences.slice(0, 2).join('. ').trim();
    } else {
      summary = sentences.slice(0, 2).join('. ').trim();
    }
    
    if (summary.length > 200) {
      summary = summary.substring(0, 197) + '...';
    }
    
    return summary + '.';
  }
}

export default new EnhancedFileProcessingService();