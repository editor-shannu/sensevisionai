export const GOOGLE_CLOUD_API_KEY = 'AQ.Ab8RN6L8oL0YdRyl1FfyYVeIJ-eb3LQmJPAYc4slnkRf6Ly0Ug';

export const API_ENDPOINTS = {
  VISION: 'https://vision.googleapis.com/v1/images:annotate',
  SPEECH_TO_TEXT: 'https://speech.googleapis.com/v1/speech:recognize',
  TEXT_TO_SPEECH: 'https://texttospeech.googleapis.com/v1/text:synthesize',
  VERTEX_AI: 'https://us-central1-aiplatform.googleapis.com/v1/projects/YOUR_PROJECT/locations/us-central1/publishers/google/models/gemini-pro-vision:predict'
};

export const SUPPORTED_LANGUAGES = [
  { code: 'en-US', name: 'English', voice: 'en-US-Standard-A' },
  { code: 'hi-IN', name: 'Hindi', voice: 'hi-IN-Standard-A' },
  { code: 'te-IN', name: 'Telugu', voice: 'te-IN-Standard-A' }
];

export const VOICE_COMMANDS = [
  { command: 'read next page', action: 'nextPage', description: 'Move to next page' },
  { command: 'repeat last line', action: 'repeatLine', description: 'Repeat the last sentence' },
  { command: 'slow down', action: 'slowDown', description: 'Decrease reading speed' },
  { command: 'speed up', action: 'speedUp', description: 'Increase reading speed' },
  { command: 'pause reading', action: 'pause', description: 'Pause the narration' },
  { command: 'resume reading', action: 'resume', description: 'Resume the narration' },
  { command: 'explain this', action: 'explain', description: 'Get AI explanation of content' }
];

export const EMOTION_STYLES = {
  storytelling: {
    rate: '0.9',
    pitch: '+2st',
    volume: '+2dB',
    emphasis: 'strong'
  },
  instruction: {
    rate: '0.8',
    pitch: '0st',
    volume: '0dB',
    emphasis: 'moderate'
  },
  academic: {
    rate: '0.85',
    pitch: '-1st',
    volume: '0dB',
    emphasis: 'reduced'
  }
};